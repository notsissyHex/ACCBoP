namespace offsets
{
	namespace ATS_Fireworks_Shell_C
	{
			constexpr auto UberGraphFrame = 0x220; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto RotatingMovement1 = 0x228; // Size: 8, Type: struct URotatingMovementComponent*
			constexpr auto Shell Trail = 0x230; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto Sphere1 = 0x238; // Size: 8, Type: struct USphereComponent*
			constexpr auto ProjectileMovement1 = 0x240; // Size: 8, Type: struct UProjectileMovementComponent*
			constexpr auto BurstShapeScaler_Scale_83FB1B9842F674C2E551BD822515228D = 0x248; // Size: 4, Type: float
			constexpr auto BurstShapeScaler__Direction_83FB1B9842F674C2E551BD822515228D = 0x24c; // Size: 1, Type: enum class ETimelineDirection
			constexpr auto BurstShapeScaler = 0x250; // Size: 8, Type: struct UTimelineComponent*
			constexpr auto Max Rotation Speed = 0x258; // Size: 4, Type: float
			constexpr auto Min Rotation Speed = 0x25c; // Size: 4, Type: float
			constexpr auto Max Launch Velocity = 0x260; // Size: 4, Type: float
			constexpr auto Min Launch velocity = 0x264; // Size: 4, Type: float
			constexpr auto Shell Max Life = 0x268; // Size: 4, Type: float
			constexpr auto Shell min life = 0x26c; // Size: 4, Type: float
			constexpr auto MaxBurstTime = 0x270; // Size: 4, Type: float
			constexpr auto MinBurstTime = 0x274; // Size: 4, Type: float
			constexpr auto BurstParticleSystem = 0x278; // Size: 8, Type: struct UParticleSystem*
			constexpr auto BurstStarColors = 0x280; // Size: 16, Type: struct TArray<struct FLinearColor>
			constexpr auto SparkleColors = 0x290; // Size: 16, Type: struct TArray<struct FLinearColor>
			constexpr auto ShellParticleSystem = 0x2a0; // Size: 8, Type: struct UParticleSystem*
			constexpr auto ParticleLife = 0x2a8; // Size: 4, Type: float
			constexpr auto BurstTime = 0x2ac; // Size: 4, Type: float
			constexpr auto NumberOfBursts = 0x2b0; // Size: 4, Type: int32_t
			constexpr auto SecondaryBurstDelay = 0x2b4; // Size: 4, Type: float
			constexpr auto FlareColor = 0x2b8; // Size: 16, Type: struct FLinearColor
			constexpr auto ShellTailColor = 0x2c8; // Size: 16, Type: struct FLinearColor
			constexpr auto DoShapedBurst = 0x2d8; // Size: 1, Type: bool
			constexpr auto UseShellSmoke = 0x2d9; // Size: 1, Type: bool
			constexpr auto UseBurstSmoke = 0x2da; // Size: 1, Type: bool
			constexpr auto BurstSparkleMultiplier = 0x2dc; // Size: 4, Type: float
			constexpr auto ShellSparkleMultiplier = 0x2e0; // Size: 4, Type: float
			constexpr auto BurstStarMultiplier = 0x2e4; // Size: 4, Type: float
			constexpr auto BlankMaterial = 0x2e8; // Size: 8, Type: struct UMaterial*
			constexpr auto ShapedBurstActorMesh = 0x2f0; // Size: 8, Type: struct USkeletalMesh*
			constexpr auto ShapeActor = 0x2f8; // Size: 8, Type: struct AActor*
			constexpr auto ShapedBurstParticleSystem = 0x300; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto RandomRotation = 0x308; // Size: 1, Type: bool
	}
} 
