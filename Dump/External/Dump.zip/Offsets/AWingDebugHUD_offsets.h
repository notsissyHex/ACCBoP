namespace offsets
{
	namespace AWingDebugHUD
	{
	}
} 
