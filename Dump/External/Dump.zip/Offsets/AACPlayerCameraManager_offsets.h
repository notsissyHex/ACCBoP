namespace offsets
{
	namespace AACPlayerCameraManager
	{
			constexpr auto OnCameraChangeUI = 0x27e0; // Size: 16, Type: struct FMulticastInlineDelegate
			constexpr auto PhotomodeSettings = 0x27f0; // Size: 32, Type: struct FACPhotomodeSettings
			constexpr auto FreeCameraActor = 0x2818; // Size: 8, Type: struct AAcFreeCameraActor*
			constexpr auto HelicamActor = 0x2820; // Size: 8, Type: struct AHeliCamera*
			constexpr auto CameraSettings = 0x2890; // Size: 248, Type: struct FACCameraSettings
			constexpr auto OnboardSettings = 0x2988; // Size: 80, Type: struct FACOnboardCameraSettings
	}
} 
