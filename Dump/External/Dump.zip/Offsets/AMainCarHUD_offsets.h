namespace offsets
{
	namespace AMainCarHUD
	{
			constexpr auto LastActiveMfdWidgetIndex = 0x348; // Size: 4, Type: int32_t
			constexpr auto OnHudTick = 0x350; // Size: 16, Type: struct FMulticastInlineDelegate
			constexpr auto CurrentChildHUD = 0x360; // Size: 8, Type: struct AAcChildHUD*
			constexpr auto RootWidget = 0x3a0; // Size: 8, Type: struct UMainCarHUDWidgetHost*
	}
} 
