namespace offsets
{
	namespace AOnlineBeaconHost
	{
			constexpr auto ListenPort = 0x250; // Size: 4, Type: int32_t
			constexpr auto ClientActors = 0x258; // Size: 16, Type: struct TArray<struct AOnlineBeaconClient*>
	}
} 
