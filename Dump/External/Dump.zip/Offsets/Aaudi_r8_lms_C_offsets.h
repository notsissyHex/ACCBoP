namespace offsets
{
	namespace Aaudi_r8_lms_C
	{
			constexpr auto UberGraphFrame = 0x4030; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto DigitalDisplayRacelogic = 0x4038; // Size: 8, Type: struct UWidgetComponent*
			constexpr auto Racelogic_Mesh = 0x4040; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto WidgetDigitalDisplaySAS = 0x4048; // Size: 8, Type: struct UWidgetComponent*
			constexpr auto SAS_Mesh = 0x4050; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto DecalRoof_Monta_REF = 0x4058; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFrontMonta_REF = 0x4060; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassBonnetIGT_REF = 0x4068; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRearIGT_REF = 0x4070; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalDoorL_REF = 0x4078; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalDoorR_REF = 0x4080; // Size: 8, Type: struct UDecalComponent*
			constexpr auto AuxLightINT = 0x4088; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto AuxLightPhys = 0x4090; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto WingFin = 0x4098; // Size: 8, Type: struct UWingComponent*
			constexpr auto ClassFrontAust_REF = 0x40a0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalBonnet888_REF = 0x40a8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRear888_REF = 0x40b0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRoof888_REF = 0x40b8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto BackFireL = 0x40c0; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto BackFireR = 0x40c8; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ClassBonnet_REF2 = 0x40d0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRear_REF2 = 0x40d8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFront_REF = 0x40e0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalBonnet_REF = 0x40e8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DownForceRR = 0x40f0; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DownForceRL = 0x40f8; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DownForceFR = 0x4100; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DownForceFL = 0x4108; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto ClassRear_REF = 0x4110; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalRoof_REF = 0x4118; // Size: 8, Type: struct UDecalComponent*
			constexpr auto TestSpark = 0x4120; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ParticleSystem3 = 0x4128; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ParticleSystem2 = 0x4130; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ParticleSystem1 = 0x4138; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto Driver_Enter_Exit = 0x4140; // Size: 8, Type: struct UArrowComponent*
	}
} 
