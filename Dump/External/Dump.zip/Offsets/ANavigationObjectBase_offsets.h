namespace offsets
{
	namespace ANavigationObjectBase
	{
			constexpr auto CapsuleComponent = 0x228; // Size: 8, Type: struct UCapsuleComponent*
			constexpr auto GoodSprite = 0x230; // Size: 8, Type: struct UBillboardComponent*
			constexpr auto BadSprite = 0x238; // Size: 8, Type: struct UBillboardComponent*
			constexpr auto bIsPIEPlayerStart = 0x240; // Size: 1, Type: char
	}
} 
