namespace offsets
{
	namespace ABP_Pitcrew_Idle_C
	{
			constexpr auto Pit_Crew = 0x220; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto DefaultSceneRoot = 0x228; // Size: 8, Type: struct USceneComponent*
	}
} 
