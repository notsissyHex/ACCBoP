namespace offsets
{
	namespace ABoxReflectionCapture
	{
	}
} 
