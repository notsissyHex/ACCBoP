namespace offsets
{
	namespace ALandscapeMeshProxyActor
	{
			constexpr auto LandscapeMeshProxyComponent = 0x220; // Size: 8, Type: struct ULandscapeMeshProxyComponent*
	}
} 
