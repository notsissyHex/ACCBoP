namespace offsets
{
	namespace ALandscapeStreamingProxy
	{
			constexpr auto LandscapeActor = 0x598; // Size: 28, Type: 
	}
} 
