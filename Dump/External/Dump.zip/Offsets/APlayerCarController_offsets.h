namespace offsets
{
	namespace APlayerCarController
	{
			constexpr auto wReplayHud = 0x610; // Size: 8, Type: UUserWidget*
			constexpr auto ReplayHUD = 0x618; // Size: 8, Type: struct UUserWidget*
	}
} 
