namespace offsets
{
	namespace AAcTrackReflectionController
	{
			constexpr auto SecondsBetweenTotalRefresh = 0x220; // Size: 4, Type: float
	}
} 
