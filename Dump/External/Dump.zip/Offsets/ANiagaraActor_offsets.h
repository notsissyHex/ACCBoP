namespace offsets
{
	namespace ANiagaraActor
	{
			constexpr auto NiagaraComponent = 0x220; // Size: 8, Type: struct UNiagaraComponent*
			constexpr auto bDestroyOnSystemFinish = 0x228; // Size: 1, Type: char
	}
} 
