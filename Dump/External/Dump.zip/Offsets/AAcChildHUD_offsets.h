namespace offsets
{
	namespace AAcChildHUD
	{
			constexpr auto Car = 0x310; // Size: 8, Type: struct ACarAvatar*
			constexpr auto FocusedCar = 0x318; // Size: 8, Type: struct ACarAvatar*
			constexpr auto PlayerCar = 0x320; // Size: 8, Type: struct ACarAvatar*
			constexpr auto HUDFont = 0x330; // Size: 8, Type: struct UFont*
			constexpr auto HUDFontBold = 0x338; // Size: 8, Type: struct UFont*
	}
} 
