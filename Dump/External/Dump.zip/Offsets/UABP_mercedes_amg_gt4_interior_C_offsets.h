namespace offsets
{
	namespace UABP_mercedes_amg_gt4_interior_C
	{
			constexpr auto UberGraphFrame = 0x320; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x328; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_TransitionResult = 0x358; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_StateResult_2 = 0x380; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer = 0x3b0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_5 = 0x430; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequenceEvaluator_4 = 0x4f8; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_ApplyAdditive_4 = 0x548; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_3 = 0x610; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ComponentToLocalSpace = 0x6d8; // Size: 32, Type: struct FAnimNode_ConvertComponentToLocalSpace
			constexpr auto AnimGraphNode_ModifyBone = 0x6f8; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_MeshRefPose = 0x800; // Size: 16, Type: struct FAnimNode_MeshSpaceRefPose
			constexpr auto AnimGraphNode_SequenceEvaluator_3 = 0x810; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_ApplyAdditive_2 = 0x860; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive = 0x928; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequenceEvaluator_2 = 0x9f0; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_SequenceEvaluator = 0xa40; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_StateResult = 0xa90; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0xac0; // Size: 176, Type: struct FAnimNode_StateMachine
	}
} 
