namespace offsets
{
	namespace ACineCameraActor
	{
			constexpr auto LookatTrackingSettings = 0x7a0; // Size: 80, Type: struct FCameraLookatTrackingSettings
	}
} 
