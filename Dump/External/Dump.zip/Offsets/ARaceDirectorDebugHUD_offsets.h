namespace offsets
{
	namespace ARaceDirectorDebugHUD
	{
	}
} 
