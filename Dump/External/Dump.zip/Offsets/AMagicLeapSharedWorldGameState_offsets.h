namespace offsets
{
	namespace AMagicLeapSharedWorldGameState
	{
			constexpr auto SharedWorldData = 0x290; // Size: 16, Type: struct FMagicLeapSharedWorldSharedData
			constexpr auto AlignmentTransforms = 0x2a0; // Size: 16, Type: struct FMagicLeapSharedWorldAlignmentTransforms
			constexpr auto OnSharedWorldDataUpdated = 0x2b0; // Size: 16, Type: struct FMulticastInlineDelegate
			constexpr auto OnAlignmentTransformsUpdated = 0x2c0; // Size: 16, Type: struct FMulticastInlineDelegate
	}
} 
