namespace offsets
{
	namespace AFMODAmbientSound
	{
			constexpr auto AudioComponent = 0x220; // Size: 8, Type: struct UFMODAudioComponent*
	}
} 
