namespace offsets
{
	namespace ATriggerBase
	{
			constexpr auto CollisionComponent = 0x220; // Size: 8, Type: struct UShapeComponent*
	}
} 
