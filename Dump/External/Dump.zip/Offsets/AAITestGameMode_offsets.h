namespace offsets
{
	namespace AAITestGameMode
	{
			constexpr auto OnUILogLine = 0x2c0; // Size: 16, Type: struct FMulticastInlineDelegate
			constexpr auto GameModeWidgetClass = 0x2d0; // Size: 8, Type: UUserWidget*
			constexpr auto StepsPerFrame = 0x2d8; // Size: 4, Type: int32_t
			constexpr auto MinNSP = 0x2dc; // Size: 4, Type: float
			constexpr auto MaxNSP = 0x2e0; // Size: 4, Type: float
			constexpr auto CarsActive = 0x2e4; // Size: 4, Type: int32_t
			constexpr auto DbgInfo = 0x2e8; // Size: 16, Type: struct FString
			constexpr auto cars = 0x308; // Size: 16, Type: struct TArray<struct FAiTestCar>
			constexpr auto UiWidget = 0x318; // Size: 8, Type: struct UUserWidget*
	}
} 
