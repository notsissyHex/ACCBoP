namespace offsets
{
	namespace ATextRenderActor
	{
			constexpr auto TextRender = 0x220; // Size: 8, Type: struct UTextRenderComponent*
	}
} 
