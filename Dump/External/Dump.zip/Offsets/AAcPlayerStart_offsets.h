namespace offsets
{
	namespace AAcPlayerStart
	{
			constexpr auto StartType = 0x250; // Size: 1, Type: enum class EAcPlayerStartType
			constexpr auto StartIndex = 0x251; // Size: 1, Type: char
			constexpr auto CarLocation = 0x252; // Size: 1, Type: enum class ECarLocation
			constexpr auto IsBetween_SC_Lines = 0x253; // Size: 1, Type: bool
			constexpr auto IsSharedZone = 0x254; // Size: 1, Type: bool
			constexpr auto IsSecondaryZone = 0x255; // Size: 1, Type: bool
			constexpr auto SharedWithPosition = 0x256; // Size: 1, Type: char
			constexpr auto TextRenderComponent = 0x258; // Size: 8, Type: struct UTextRenderComponent*
			constexpr auto PanelPitstopMaterial = 0x268; // Size: 8, Type: struct UMaterialInstanceDynamic*
	}
} 
