namespace offsets
{
	namespace AInstancedFoliageActor
	{
	}
} 
