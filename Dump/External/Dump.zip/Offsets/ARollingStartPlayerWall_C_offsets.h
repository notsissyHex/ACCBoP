namespace offsets
{
	namespace ARollingStartPlayerWall_C
	{
			constexpr auto StaticMesh = 0x220; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto DefaultSceneRoot = 0x228; // Size: 8, Type: struct USceneComponent*
	}
} 
