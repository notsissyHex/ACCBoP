namespace offsets
{
	namespace AAcController
	{
			constexpr auto ForwardSpeed = 0x588; // Size: 4, Type: float
			constexpr auto LateralSpeed = 0x58c; // Size: 4, Type: float
			constexpr auto VerticalSpeed = 0x590; // Size: 4, Type: float
			constexpr auto YawSpeed = 0x594; // Size: 4, Type: float
			constexpr auto PitchSpeed = 0x598; // Size: 4, Type: float
			constexpr auto RollSpeed = 0x59c; // Size: 4, Type: float
			constexpr auto CameraSmoothness = 0x5a0; // Size: 4, Type: float
			constexpr auto CameraSpeed = 0x5a4; // Size: 4, Type: float
			constexpr auto ParticlesOffset = 0x5a8; // Size: 12, Type: struct FVector
	}
} 
