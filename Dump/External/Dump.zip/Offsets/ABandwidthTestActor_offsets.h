namespace offsets
{
	namespace ABandwidthTestActor
	{
			constexpr auto BandwidthGenerator = 0x220; // Size: 32, Type: struct FBandwidthTestGenerator
	}
} 
