namespace offsets
{
	namespace ASkyAtmosphere
	{
			constexpr auto SkyAtmosphereComponent = 0x220; // Size: 8, Type: struct USkyAtmosphereComponent*
	}
} 
