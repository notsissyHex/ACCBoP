namespace offsets
{
	namespace ALandscapeGizmoActor
	{
	}
} 
