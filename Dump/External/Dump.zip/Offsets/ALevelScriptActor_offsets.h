namespace offsets
{
	namespace ALevelScriptActor
	{
			constexpr auto bInputEnabled = 0x220; // Size: 1, Type: char
	}
} 
