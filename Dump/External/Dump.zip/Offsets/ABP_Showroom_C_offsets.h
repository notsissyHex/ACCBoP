namespace offsets
{
	namespace ABP_Showroom_C
	{
			constexpr auto SpotLight17 = 0x220; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto SpotLight15 = 0x228; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto SpotLight13 = 0x230; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto SpotLight11 = 0x238; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto SpotLight9 = 0x240; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto SpotLight6 = 0x248; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto SpotLight4 = 0x250; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto SpotLight1 = 0x258; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto SpotLight = 0x260; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto showroom1_RotatingBase = 0x268; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto showroom1_room = 0x270; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto showroom1_lights = 0x278; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto DefaultSceneRoot = 0x280; // Size: 8, Type: struct USceneComponent*
	}
} 
