namespace offsets
{
	namespace ACameraDebugHUD
	{
	}
} 
