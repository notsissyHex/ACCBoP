namespace offsets
{
	namespace ABP_GhostCarManager_C
	{
			constexpr auto DefaultSceneRoot = 0x21a8; // Size: 8, Type: struct USceneComponent*
	}
} 
