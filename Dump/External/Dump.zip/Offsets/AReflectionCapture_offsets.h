namespace offsets
{
	namespace AReflectionCapture
	{
			constexpr auto CaptureComponent = 0x220; // Size: 8, Type: struct UReflectionCaptureComponent*
	}
} 
