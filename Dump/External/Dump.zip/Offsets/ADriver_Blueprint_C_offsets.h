namespace offsets
{
	namespace ADriver_Blueprint_C
	{
			constexpr auto Driver_Head = 0x4d0; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Driver_Helmet = 0x4d8; // Size: 8, Type: struct USkeletalMeshComponent*
	}
} 
