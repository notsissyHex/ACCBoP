namespace offsets
{
	namespace Aferrari_488_gt3_C
	{
			constexpr auto UberGraphFrame = 0x4030; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto WidgetDigitalDisplaySAS = 0x4038; // Size: 8, Type: struct UWidgetComponent*
			constexpr auto SAS_Mesh = 0x4040; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto DecalFrontKessel_REF = 0x4048; // Size: 8, Type: struct UDecalComponent*
			constexpr auto NumberL_IGT = 0x4050; // Size: 8, Type: struct UDecalComponent*
			constexpr auto NumberR_IGT = 0x4058; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFrontREF_IGT = 0x4060; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFrontREF_AF19 = 0x4068; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRearREF_Hub19 = 0x4070; // Size: 8, Type: struct UDecalComponent*
			constexpr auto RearNumberTag_Tempesta219 = 0x4078; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalBonnetHB19 = 0x4080; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFront_Tempesta19 = 0x4088; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFront_AF19 = 0x4090; // Size: 8, Type: struct UDecalComponent*
			constexpr auto RearNumberTag_SMP = 0x4098; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRearSMP19 = 0x40a0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRear_Rinaldi19 = 0x40a8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto RearNumberTag_Rinaldi = 0x40b0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto AuxLightINT = 0x40b8; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto AuxLightPhys = 0x40c0; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto WingFin = 0x40c8; // Size: 8, Type: struct UWingComponent*
			constexpr auto ClassRoofT2_REF = 0x40d0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto BackFireL = 0x40d8; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto BackFireR = 0x40e0; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ClassRearAF_REF = 0x40e8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRearTP12_REF = 0x40f0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFrontTP12_REF = 0x40f8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto FuelDisplay = 0x4100; // Size: 8, Type: struct UWidgetComponent*
			constexpr auto DigitalDisplayMotec = 0x4108; // Size: 8, Type: struct UWidgetComponent*
			constexpr auto DecalFrontRinaldi_REF = 0x4110; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalBonnetRinaldi_REF = 0x4118; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFrontKessel_REF = 0x4120; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DownForceRR = 0x4128; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DownForceRL = 0x4130; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DownForceFR = 0x4138; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DownForceFL = 0x4140; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto ClassFrontREF = 0x4148; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRearREF = 0x4150; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalRoofREF = 0x4158; // Size: 8, Type: struct UDecalComponent*
			constexpr auto TestSpark = 0x4160; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ParticleSystem3 = 0x4168; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ParticleSystem2 = 0x4170; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ParticleSystem1 = 0x4178; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto Driver_Enter_Exit = 0x4180; // Size: 8, Type: struct UArrowComponent*
	}
} 
