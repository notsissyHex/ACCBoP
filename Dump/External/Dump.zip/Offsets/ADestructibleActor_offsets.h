namespace offsets
{
	namespace ADestructibleActor
	{
			constexpr auto DestructibleComponent = 0x220; // Size: 8, Type: struct UDestructibleComponent*
			constexpr auto OnActorFracture = 0x228; // Size: 16, Type: struct FMulticastInlineDelegate
	}
} 
