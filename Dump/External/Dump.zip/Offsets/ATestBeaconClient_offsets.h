namespace offsets
{
	namespace ATestBeaconClient
	{
	}
} 
