namespace offsets
{
	namespace AProceduralFoliageBlockingVolume
	{
			constexpr auto ProceduralFoliageVolume = 0x258; // Size: 8, Type: struct AProceduralFoliageVolume*
	}
} 
