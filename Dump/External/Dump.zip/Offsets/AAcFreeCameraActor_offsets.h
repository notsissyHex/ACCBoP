namespace offsets
{
	namespace AAcFreeCameraActor
	{
			constexpr auto PhotoSettings = 0x220; // Size: 64, Type: struct FPhotomodeSettings
			constexpr auto SceneComponent = 0x260; // Size: 8, Type: struct USceneComponent*
			constexpr auto CameraComponent = 0x268; // Size: 8, Type: struct UCineCameraComponent*
			constexpr auto VRCamera = 0x270; // Size: 8, Type: struct UCameraComponent*
	}
} 
