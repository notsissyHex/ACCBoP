namespace offsets
{
	namespace APrecomputedVisibilityVolume
	{
	}
} 
