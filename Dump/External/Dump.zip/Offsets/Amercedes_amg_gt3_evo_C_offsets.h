namespace offsets
{
	namespace Amercedes_amg_gt3_evo_C
	{
			constexpr auto UberGraphFrame = 0x41e0; // Size: 8, Type: struct FPointerToUberGraphFrame
	}
} 
