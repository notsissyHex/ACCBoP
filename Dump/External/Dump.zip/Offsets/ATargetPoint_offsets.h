namespace offsets
{
	namespace ATargetPoint
	{
	}
} 
