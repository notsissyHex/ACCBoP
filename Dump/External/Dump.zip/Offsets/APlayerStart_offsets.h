namespace offsets
{
	namespace APlayerStart
	{
			constexpr auto PlayerStartTag = 0x248; // Size: 8, Type: struct FName
	}
} 
