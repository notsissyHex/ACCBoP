namespace offsets
{
	namespace AAcPlayerStartManager
	{
			constexpr auto bIsPitlaneOnLeft = 0x230; // Size: 1, Type: bool
			constexpr auto SplineComponent = 0x238; // Size: 8, Type: struct USplineComponent*
			constexpr auto PitAlignmentRange = 0x240; // Size: 4, Type: float
			constexpr auto PlayerStartPrefix = 0x248; // Size: 16, Type: struct FString
			constexpr auto bIsFirstZero = 0x258; // Size: 1, Type: bool
			constexpr auto isPolesitterOnLeft = 0x259; // Size: 1, Type: bool
			constexpr auto space_between_car_m = 0x25c; // Size: 4, Type: float
			constexpr auto pit_count = 0x260; // Size: 4, Type: int32_t
			constexpr auto PlayerStartType = 0x264; // Size: 1, Type: enum class EAcPlayerStartType
	}
} 
