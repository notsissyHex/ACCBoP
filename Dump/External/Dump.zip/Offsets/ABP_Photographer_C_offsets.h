namespace offsets
{
	namespace ABP_Photographer_C
	{
			constexpr auto UberGraphFrame = 0x220; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto Photo-man_C = 0x228; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto Photo-man_B = 0x230; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto Photo-man_A = 0x238; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto DefaultSceneRoot = 0x240; // Size: 8, Type: struct USceneComponent*
			constexpr auto AnimationStart = 0x248; // Size: 16, Type: struct TArray<float>
			constexpr auto Index = 0x258; // Size: 4, Type: int32_t
			constexpr auto Seconds = 0x25c; // Size: 4, Type: float
			constexpr auto CurrentSkeletal = 0x260; // Size: 8, Type: struct USkeletalMeshComponent*
	}
} 
