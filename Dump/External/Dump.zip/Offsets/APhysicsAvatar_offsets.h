namespace offsets
{
	namespace APhysicsAvatar
	{
	}
} 
