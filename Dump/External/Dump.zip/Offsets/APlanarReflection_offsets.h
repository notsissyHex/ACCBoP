namespace offsets
{
	namespace APlanarReflection
	{
			constexpr auto PlanarReflectionComponent = 0x230; // Size: 8, Type: struct UPlanarReflectionComponent*
			constexpr auto bShowPreviewPlane = 0x238; // Size: 1, Type: bool
	}
} 
