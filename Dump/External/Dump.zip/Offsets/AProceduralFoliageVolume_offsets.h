namespace offsets
{
	namespace AProceduralFoliageVolume
	{
			constexpr auto ProceduralComponent = 0x258; // Size: 8, Type: struct UProceduralFoliageComponent*
	}
} 
