namespace offsets
{
	namespace ATrackAvatar
	{
			constexpr auto TrackName = 0x220; // Size: 16, Type: struct FString
			constexpr auto ConfigName = 0x230; // Size: 16, Type: struct FString
			constexpr auto PhysicsDataCache = 0x240; // Size: 8, Type: struct UTrackPhysicsDataCache*
			constexpr auto ReflectionBrightnessCurve = 0x248; // Size: 8, Type: struct UCurveFloat*
			constexpr auto ReflBrightnessCloudDensity = 0x250; // Size: 8, Type: struct UCurveFloat*
			constexpr auto SunShadowBiasCurve = 0x258; // Size: 8, Type: struct UCurveFloat*
			constexpr auto Genome = 0x260; // Size: 8, Type: struct UTrackGenome*
			constexpr auto SurfaceData = 0x268; // Size: 16, Type: struct TArray<struct USurfaceData*>
			constexpr auto TrackPeopleController = 0x278; // Size: 8, Type: struct UTrackPeopleController*
			constexpr auto StartingLightsMaterials = 0x298; // Size: 16, Type: struct TArray<struct UMaterialInstanceDynamic*>
			constexpr auto GreenFlagTriggerRange = 0x2a8; // Size: 8, Type: struct FVector2D
			constexpr auto FormationLapTrigger = 0x2b0; // Size: 4, Type: float
			constexpr auto normalizedSectorLimits = 0x2b8; // Size: 16, Type: struct TArray<float>
	}
} 
