namespace offsets
{
	namespace APlaneReflectionCapture
	{
	}
} 
