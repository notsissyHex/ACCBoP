namespace offsets
{
	namespace AAudioActor
	{
	}
} 
