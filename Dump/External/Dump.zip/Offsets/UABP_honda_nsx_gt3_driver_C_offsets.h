namespace offsets
{
	namespace UABP_honda_nsx_gt3_driver_C
	{
			constexpr auto UberGraphFrame = 0x3c0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x3c8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_SequencePlayer_22 = 0x3f8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_26 = 0x478; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_BlendSpacePlayer_4 = 0x540; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_25 = 0x628; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_21 = 0x6f0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_24 = 0x770; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_23 = 0x838; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_20 = 0x900; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_22 = 0x980; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_19 = 0xa48; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_21 = 0xac8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_18 = 0xb90; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_17 = 0xc10; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_20 = 0xc90; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_16 = 0xd58; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_19 = 0xdd8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_15 = 0xea0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_14 = 0xf20; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_18 = 0xfa0; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_13 = 0x1068; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_12 = 0x10e8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_17 = 0x1168; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_11 = 0x1230; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_16 = 0x12b0; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_15 = 0x1378; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_14 = 0x1440; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_13 = 0x1508; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_10 = 0x15d0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_9 = 0x1650; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_8 = 0x16d0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_BlendSpacePlayer_3 = 0x1750; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_BlendSpacePlayer_2 = 0x1838; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_SequencePlayer_7 = 0x1920; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_12 = 0x19a0; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_6 = 0x1a68; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_5 = 0x1ae8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_4 = 0x1b68; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_3 = 0x1be8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_2 = 0x1c68; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_11 = 0x1ce8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_10 = 0x1db0; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_9 = 0x1e78; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_8 = 0x1f40; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_7 = 0x2008; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_6 = 0x20d0; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer = 0x2198; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_5 = 0x2218; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequenceEvaluator = 0x22e0; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_ApplyAdditive_4 = 0x2330; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_3 = 0x23f8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_2 = 0x24c0; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_BlendSpacePlayer = 0x2588; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_ApplyAdditive = 0x2670; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_StateResult = 0x2738; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0x2768; // Size: 176, Type: struct FAnimNode_StateMachine
	}
} 
