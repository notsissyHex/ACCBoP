namespace offsets
{
	namespace AAIHUD
	{
	}
} 
