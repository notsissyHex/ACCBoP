namespace offsets
{
	namespace AProximityHUD
	{
	}
} 
