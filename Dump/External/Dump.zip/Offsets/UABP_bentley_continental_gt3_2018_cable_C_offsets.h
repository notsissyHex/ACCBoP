namespace offsets
{
	namespace UABP_bentley_continental_gt3_2018_cable_C
	{
			constexpr auto UberGraphFrame = 0x2e0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x2e8; // Size: 48, Type: struct FAnimNode_Root
	}
} 
