namespace offsets
{
	namespace ANavigationGraphNode
	{
	}
} 
