namespace offsets
{
	namespace AAcSpotter
	{
			constexpr auto AudioComms = 0x240; // Size: 8, Type: struct UAudioComms*
			constexpr auto audioPlayedData = 0x2b8; // Size: 80, Type: struct TMap<enum class EAudioCommsDataType, struct FCommLogData>
			constexpr auto levelValues = 0x308; // Size: 80, Type: struct TMap<enum class EAudioCommsLevel, struct FCommLevelValues>
			constexpr auto fGuids = 0x358; // Size: 80, Type: struct TMap<enum class EAudioCommsGuidCategory, struct FGuid>
	}
} 
