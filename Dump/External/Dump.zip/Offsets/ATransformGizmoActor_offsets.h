namespace offsets
{
	namespace ATransformGizmoActor
	{
			constexpr auto TranslateX = 0x220; // Size: 8, Type: struct UPrimitiveComponent*
			constexpr auto TranslateY = 0x228; // Size: 8, Type: struct UPrimitiveComponent*
			constexpr auto TranslateZ = 0x230; // Size: 8, Type: struct UPrimitiveComponent*
			constexpr auto TranslateYZ = 0x238; // Size: 8, Type: struct UPrimitiveComponent*
			constexpr auto TranslateXZ = 0x240; // Size: 8, Type: struct UPrimitiveComponent*
			constexpr auto TranslateXY = 0x248; // Size: 8, Type: struct UPrimitiveComponent*
			constexpr auto RotateX = 0x250; // Size: 8, Type: struct UPrimitiveComponent*
			constexpr auto RotateY = 0x258; // Size: 8, Type: struct UPrimitiveComponent*
			constexpr auto RotateZ = 0x260; // Size: 8, Type: struct UPrimitiveComponent*
			constexpr auto UniformScale = 0x268; // Size: 8, Type: struct UPrimitiveComponent*
			constexpr auto AxisScaleX = 0x270; // Size: 8, Type: struct UPrimitiveComponent*
			constexpr auto AxisScaleY = 0x278; // Size: 8, Type: struct UPrimitiveComponent*
			constexpr auto AxisScaleZ = 0x280; // Size: 8, Type: struct UPrimitiveComponent*
			constexpr auto PlaneScaleYZ = 0x288; // Size: 8, Type: struct UPrimitiveComponent*
			constexpr auto PlaneScaleXZ = 0x290; // Size: 8, Type: struct UPrimitiveComponent*
			constexpr auto PlaneScaleXY = 0x298; // Size: 8, Type: struct UPrimitiveComponent*
	}
} 
