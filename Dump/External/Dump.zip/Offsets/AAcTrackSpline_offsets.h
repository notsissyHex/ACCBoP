namespace offsets
{
	namespace AAcTrackSpline
	{
			constexpr auto SplineComponent = 0x220; // Size: 8, Type: struct USplineComponent*
			constexpr auto ImportFewPoints = 0x228; // Size: 1, Type: bool
			constexpr auto SplinePointOffset = 0x22c; // Size: 4, Type: int32_t
	}
} 
