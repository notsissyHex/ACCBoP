namespace offsets
{
	namespace AMagicLeapSharedWorldPlayerController
	{
	}
} 
