namespace offsets
{
	namespace ABP_SpectatorPawn_C
	{
	}
} 
