namespace offsets
{
	namespace Ajaguar_g3_C
	{
			constexpr auto UberGraphFrame = 0x4030; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto SAS_Mesh = 0x4038; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto WidgetDigitalDisplaySAS = 0x4040; // Size: 8, Type: struct UWidgetComponent*
			constexpr auto BackFireL = 0x4048; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto BackFireR = 0x4050; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto TestSpark = 0x4058; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto NumberTag_20 = 0x4060; // Size: 8, Type: struct UDecalComponent*
			constexpr auto AuxLightINT = 0x4068; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto AuxLightPhys = 0x4070; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto WingFin = 0x4078; // Size: 8, Type: struct UWingComponent*
			constexpr auto WidgetDigitalDisplayRacelogic = 0x4080; // Size: 8, Type: struct UWidgetComponent*
			constexpr auto SteerCable = 0x4088; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto ClassRearREFEmilFrey = 0x4090; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFrontREFEmilFrey = 0x4098; // Size: 8, Type: struct UDecalComponent*
			constexpr auto PlateFrontREFEmilFrey = 0x40a0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DownForceRR = 0x40a8; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DownForceRL = 0x40b0; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DownForceFR = 0x40b8; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DownForceFL = 0x40c0; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto ParticleSystem3 = 0x40c8; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ParticleSystem2 = 0x40d0; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ParticleSystem1 = 0x40d8; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto Driver_Enter_Exit = 0x40e0; // Size: 8, Type: struct UArrowComponent*
	}
} 
