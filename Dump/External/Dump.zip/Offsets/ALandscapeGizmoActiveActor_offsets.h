namespace offsets
{
	namespace ALandscapeGizmoActiveActor
	{
	}
} 
