namespace offsets
{
	namespace AAiCarController
	{
	}
} 
