namespace offsets
{
	namespace AShowRoomCameraActor_C
	{
			constexpr auto UberGraphFrame = 0x7a0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto Target = 0x7a8; // Size: 8, Type: struct AActor*
			constexpr auto TargetOffset = 0x7b0; // Size: 12, Type: struct FVector
			constexpr auto ExtraTargetHeightOffset = 0x7bc; // Size: 4, Type: float
			constexpr auto HeightLimits = 0x7c0; // Size: 8, Type: struct FVector2D
			constexpr auto YawLimits = 0x7c8; // Size: 8, Type: struct FVector2D
			constexpr auto FovLimits = 0x7d0; // Size: 8, Type: struct FVector2D
			constexpr auto MenuGameMode = 0x7d8; // Size: 8, Type: struct ABP_MenuGameMode_C*
			constexpr auto DefaultFovLimits = 0x7e0; // Size: 8, Type: struct FVector2D
			constexpr auto PreviousAspectRatio = 0x7e8; // Size: 4, Type: float
			constexpr auto AcGameInstance = 0x7f0; // Size: 8, Type: struct UAcGameInstance*
			constexpr auto IsHMDEnabled = 0x7f8; // Size: 1, Type: bool
			constexpr auto AllowControl = 0x7f9; // Size: 1, Type: bool
			constexpr auto TrackTarget = 0x7fa; // Size: 1, Type: bool
	}
} 
