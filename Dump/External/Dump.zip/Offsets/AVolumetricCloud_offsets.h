namespace offsets
{
	namespace AVolumetricCloud
	{
			constexpr auto VolumetricCloudComponent = 0x220; // Size: 8, Type: struct UVolumetricCloudComponent*
	}
} 
