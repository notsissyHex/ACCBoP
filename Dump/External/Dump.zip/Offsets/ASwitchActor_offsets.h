namespace offsets
{
	namespace ASwitchActor
	{
			constexpr auto SceneComponent = 0x238; // Size: 8, Type: struct USceneComponent*
			constexpr auto LastSelectedOption = 0x240; // Size: 4, Type: int32_t
	}
} 
