namespace offsets
{
	namespace Asilverstone_C
	{
	}
} 
