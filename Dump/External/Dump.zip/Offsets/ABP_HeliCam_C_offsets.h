namespace offsets
{
	namespace ABP_HeliCam_C
	{
			constexpr auto AudioComponent = 0x810; // Size: 8, Type: struct UFMODAudioComponent*
	}
} 
