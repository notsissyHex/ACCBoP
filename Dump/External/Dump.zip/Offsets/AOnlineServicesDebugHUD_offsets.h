namespace offsets
{
	namespace AOnlineServicesDebugHUD
	{
	}
} 
