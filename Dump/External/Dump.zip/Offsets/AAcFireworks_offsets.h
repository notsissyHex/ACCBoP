namespace offsets
{
	namespace AAcFireworks
	{
			constexpr auto raceGameMode = 0x220; // Size: 8, Type: struct AAcRaceGameMode*
	}
} 
