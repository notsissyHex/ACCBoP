namespace offsets
{
	namespace ABP_MenuController_C
	{
			constexpr auto UberGraphFrame = 0x5e0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto DeadZone = 0x5e8; // Size: 4, Type: float
			constexpr auto keydown = 0x5ec; // Size: 1, Type: bool
			constexpr auto ShowRoomCamera = 0x5f0; // Size: 8, Type: struct AShowRoomCameraActor_C*
			constexpr auto ShowroomCarRotationMultiplier = 0x5f8; // Size: 4, Type: float
			constexpr auto ShowroomCameraZoomMultiplier = 0x5fc; // Size: 4, Type: float
			constexpr auto ShowroomCameraHeightMultiplier = 0x600; // Size: 4, Type: float
			constexpr auto HeightValue = 0x604; // Size: 4, Type: float
			constexpr auto YawValue = 0x608; // Size: 4, Type: float
			constexpr auto ZoomValue = 0x60c; // Size: 4, Type: float
			constexpr auto PreviousAspectRatio = 0x610; // Size: 4, Type: float
			constexpr auto CockpitPanValue = 0x614; // Size: 4, Type: float
			constexpr auto CockpitFovLimits = 0x618; // Size: 8, Type: struct FVector2D
			constexpr auto CockpitFOV = 0x620; // Size: 4, Type: float
			constexpr auto TeamFOV = 0x624; // Size: 4, Type: float
			constexpr auto CloseUpFOV = 0x628; // Size: 4, Type: float
	}
} 
