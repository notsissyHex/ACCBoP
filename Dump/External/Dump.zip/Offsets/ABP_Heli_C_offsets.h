namespace offsets
{
	namespace ABP_Heli_C
	{
			constexpr auto UberGraphFrame = 0x220; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto BackRotorLod0 = 0x228; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto HeliLod0 = 0x230; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto RotorLod0 = 0x238; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto DefaultSceneRoot = 0x240; // Size: 8, Type: struct USceneComponent*
			constexpr auto RotorSpeed = 0x248; // Size: 4, Type: float
			constexpr auto IsFlying = 0x24c; // Size: 1, Type: bool
			constexpr auto RotorFlyingSpeed = 0x250; // Size: 4, Type: float
			constexpr auto BlinkTime = 0x254; // Size: 4, Type: float
			constexpr auto BlinkMaterialInstance = 0x258; // Size: 8, Type: struct UMaterialInstanceDynamic*
			constexpr auto IsBlinkOn = 0x260; // Size: 1, Type: bool
			constexpr auto emissive = 0x264; // Size: 4, Type: float
	}
} 
