namespace offsets
{
	namespace AInternalToolFrameworkActor
	{
	}
} 
