namespace offsets
{
	namespace ABP_PlayerStart_C
	{
			constexpr auto reference_pitStop_placement1 = 0x290; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto StaticMesh = 0x298; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto reference_pitStop_placement = 0x2a0; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto MaterialMesh = 0x2a8; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Floor = 0x2b0; // Size: 8, Type: struct UStaticMeshComponent*
	}
} 
