namespace offsets
{
	namespace AAcRaceGameState
	{
			constexpr auto MaxWindSpeed = 0x270; // Size: 4, Type: float
			constexpr auto RainActorClass = 0x278; // Size: 8, Type: ARainBase*
			constexpr auto MaxNumCarsCastingShadows = 0x280; // Size: 4, Type: int32_t
			constexpr auto OpponentCarLightRadius = 0x284; // Size: 4, Type: float
			constexpr auto ReplayCarLightRadius = 0x288; // Size: 4, Type: float
			constexpr auto ReplayCarLightMultiplier = 0x28c; // Size: 4, Type: float
			constexpr auto CarOpponentVisCheckFrequency = 0x290; // Size: 4, Type: float
			constexpr auto WetTrackDropsCurve = 0x298; // Size: 8, Type: struct UCurveVector*
			constexpr auto AudioInternalScale = 0x2a0; // Size: 4, Type: float
			constexpr auto VolumeFadeInTime = 0x2a4; // Size: 4, Type: float
			constexpr auto AudioStartingTime = 0x2a8; // Size: 4, Type: float
			constexpr auto CameraStartRampVolume = 0x2ac; // Size: 4, Type: float
			constexpr auto PuddleLevelSmoothValue = 0x2b0; // Size: 4, Type: float
			constexpr auto PuddleGain = 0x2b4; // Size: 4, Type: float
			constexpr auto ReverbReduction = 0x2b8; // Size: 4, Type: float
			constexpr auto OpponentEngineVolume = 0x2bc; // Size: 4, Type: float
			constexpr auto InvertedScaleBehavior = 0x2c0; // Size: 1, Type: bool
			constexpr auto AudioScaleMaxSpeed = 0x2c4; // Size: 4, Type: float
			constexpr auto OpponentEngineChaseCamVolume = 0x2c8; // Size: 4, Type: float
			constexpr auto AudioFadingCars = 0x2cc; // Size: 4, Type: int32_t
			constexpr auto AudioListenerCars = 0x2d0; // Size: 4, Type: int32_t
			constexpr auto DistanceFadingCars = 0x2d4; // Size: 4, Type: float
			constexpr auto MaxDistanceListenerCars = 0x2d8; // Size: 4, Type: float
			constexpr auto EngineExtVolumeSmoothOn = 0x2dc; // Size: 4, Type: float
			constexpr auto EngineExtVolumeSmoothOff = 0x2e0; // Size: 4, Type: float
			constexpr auto PassByFactorVariation = 0x2e4; // Size: 4, Type: float
			constexpr auto DirectionalFactorVariation = 0x2e8; // Size: 4, Type: float
			constexpr auto NumOpponentsVolumeReductionInt = 0x2ec; // Size: 4, Type: int32_t
			constexpr auto OpponentListenerReductionFactorInt = 0x2f0; // Size: 4, Type: float
			constexpr auto OpponentListenerDistanceInt = 0x2f4; // Size: 4, Type: float
			constexpr auto NumOpponentsVolumeReductionExt = 0x2f8; // Size: 4, Type: int32_t
			constexpr auto OpponentListenerReductionFactorExt = 0x2fc; // Size: 4, Type: float
			constexpr auto MaxCarListenerFromDifferentLocation = 0x300; // Size: 4, Type: int32_t
			constexpr auto MinPressureForDeflationWarning = 0x304; // Size: 4, Type: float
			constexpr auto StepForDeflationComunication = 0x308; // Size: 4, Type: float
			constexpr auto AudioEventOffsetTyreInflation = 0x30c; // Size: 4, Type: int32_t
			constexpr auto AudioEventOffsetTyreDeflation = 0x310; // Size: 4, Type: int32_t
			constexpr auto AudioEventOffsetTyrePressure = 0x314; // Size: 4, Type: int32_t
			constexpr auto TestMinOpponentDirt = 0x318; // Size: 4, Type: float
			constexpr auto LogAudio = 0x31c; // Size: 1, Type: enum class EAudioLog
			constexpr auto DebugAudio = 0x31d; // Size: 1, Type: bool
			constexpr auto EngineExtEnabled = 0x31e; // Size: 1, Type: bool
			constexpr auto EngineIntEnabled = 0x31f; // Size: 1, Type: bool
			constexpr auto BodyWorkEnabled = 0x320; // Size: 1, Type: bool
			constexpr auto WheelEnabled = 0x321; // Size: 1, Type: bool
			constexpr auto WindEnabled = 0x322; // Size: 1, Type: bool
			constexpr auto WindSource = 0x328; // Size: 8, Type: struct AWindDirectionalSource*
			constexpr auto RainActor = 0x330; // Size: 8, Type: struct ARainBase*
			constexpr auto ParticlesActor = 0x338; // Size: 8, Type: struct AAcParticles*
			constexpr auto SkelMeshCompList = 0x340; // Size: 16, Type: struct TArray<struct USkeletalMeshComponent*>
	}
} 
