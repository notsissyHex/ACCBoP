namespace offsets
{
	namespace ACameraTV
	{
			constexpr auto BoxCollider = 0x220; // Size: 8, Type: struct UBoxComponent*
			constexpr auto CameraComponent = 0x228; // Size: 8, Type: struct UCineCameraComponent*
			constexpr auto FovCurve = 0x230; // Size: 8, Type: struct UCurveFloat*
			constexpr auto Set = 0x238; // Size: 4, Type: int32_t
			constexpr auto ShadowExponent = 0x23c; // Size: 4, Type: float
			constexpr auto ShadowDistanceFromFocusedCar = 0x240; // Size: 4, Type: float
			constexpr auto ShadowDistanceWithoutFocusedCar = 0x244; // Size: 4, Type: float
			constexpr auto SplineComponent = 0x248; // Size: 8, Type: struct USplineComponent*
			constexpr auto bFocusCar = 0x250; // Size: 1, Type: bool
			constexpr auto bFollowSpline = 0x251; // Size: 1, Type: bool
			constexpr auto MovementSpeed = 0x254; // Size: 4, Type: float
			constexpr auto SwitchTime = 0x258; // Size: 4, Type: float
			constexpr auto SwitchLerpTime = 0x25c; // Size: 4, Type: float
			constexpr auto ActivationDistance = 0x260; // Size: 4, Type: float
			constexpr auto bIsFixed = 0x268; // Size: 1, Type: bool
	}
} 
