namespace offsets
{
	namespace ACameraShakeSourceActor
	{
			constexpr auto CameraShakeSourceComponent = 0x220; // Size: 8, Type: struct UCameraShakeSourceComponent*
	}
} 
