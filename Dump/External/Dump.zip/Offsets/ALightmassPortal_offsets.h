namespace offsets
{
	namespace ALightmassPortal
	{
			constexpr auto PortalComponent = 0x220; // Size: 8, Type: struct ULightmassPortalComponent*
	}
} 
