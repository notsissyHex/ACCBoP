namespace offsets
{
	namespace Amercedes_amg_gt3_C
	{
			constexpr auto UberGraphFrame = 0x4030; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto WidgetDigitalDisplaySAS = 0x4038; // Size: 8, Type: struct UWidgetComponent*
			constexpr auto SAS_Mesh = 0x4040; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto ClassRearFalcon_REF1 = 0x4048; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalFrontAntonelli_REF = 0x4050; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRear_IGT4 = 0x4058; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRear_IGT3 = 0x4060; // Size: 8, Type: struct UDecalComponent*
			constexpr auto NumberDoorL_IGT2 = 0x4068; // Size: 8, Type: struct UDecalComponent*
			constexpr auto NumberDoorR_IGT2 = 0x4070; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRear_IGT2 = 0x4078; // Size: 8, Type: struct UDecalComponent*
			constexpr auto NumberDoorL_IGT = 0x4080; // Size: 8, Type: struct UDecalComponent*
			constexpr auto NumberDoorR_IGT = 0x4088; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRear_IGT = 0x4090; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRearRam19_REF = 0x4098; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalFrontGruppeM_REF = 0x40a0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFrontVillorba_REF = 0x40a8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto RearNumberTagrVillorba_REF = 0x40b0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRearVillorba_REF = 0x40b8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalRoofVillorba_REF = 0x40c0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto RearNumberTagSTRAKKA_REF1 = 0x40c8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto RearNumberTagSTRAKKA_REF = 0x40d0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRearAKKA_REF19 = 0x40d8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto RearNumberTagAKKA_REF = 0x40e0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto AuxLightPhys = 0x40e8; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto AuxLightINT = 0x40f0; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto ClassFrontMANN_REF = 0x40f8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalRoofMann_REF = 0x4100; // Size: 8, Type: struct UDecalComponent*
			constexpr auto WING = 0x4108; // Size: 8, Type: struct UWingComponent*
			constexpr auto ClassFrontARC_REF = 0x4110; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalFrontARC_REF = 0x4118; // Size: 8, Type: struct UDecalComponent*
			constexpr auto BackFireL = 0x4120; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto BackFireR = 0x4128; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto TestSpark = 0x4130; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ClassFrontStrakkaE_REF = 0x4138; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRearAKKA_REF = 0x4140; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFrontAKKA_REF = 0x4148; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalRoofAKKA_REF = 0x4150; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRearStrakka_REF = 0x4158; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFrontStrakka_REF = 0x4160; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRearFalcon_REF = 0x4168; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFrontFalcon_REF = 0x4170; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DownForceRR = 0x4178; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DownForceRL = 0x4180; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DownForceFR = 0x4188; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DownForceFL = 0x4190; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto ClassRearC_REF = 0x4198; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFrontC_REF = 0x41a0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalFrontC_REF = 0x41a8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DigitalDisplayRacelogic = 0x41b0; // Size: 8, Type: struct UWidgetComponent*
			constexpr auto SteerCable = 0x41b8; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto ParticleSystem3 = 0x41c0; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ParticleSystem2 = 0x41c8; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ParticleSystem1 = 0x41d0; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto Driver_Enter_Exit = 0x41d8; // Size: 8, Type: struct UArrowComponent*
	}
} 
