namespace offsets
{
	namespace Aporsche_991ii_gt3_r_C
	{
			constexpr auto UberGraphFrame = 0x4030; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto SAS_Mesh = 0x4038; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto WidgetDigitalDisplaySAS = 0x4040; // Size: 8, Type: struct UWidgetComponent*
			constexpr auto DecalClassRearGPX1 = 0x4048; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalHoodDinamic_Frikadelli = 0x4050; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalClassRearIGT = 0x4058; // Size: 8, Type: struct UDecalComponent*
			constexpr auto Decal_DoorL = 0x4060; // Size: 8, Type: struct UDecalComponent*
			constexpr auto Decal_DoorR = 0x4068; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalRoofOpenRoad = 0x4070; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalClassRearOpenRoad = 0x4078; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalClassRearKUS = 0x4080; // Size: 8, Type: struct UDecalComponent*
			constexpr auto RearNumberTagDinamic = 0x4088; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalClassRearDinamic = 0x4090; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalHoodDinamic_ROWE = 0x4098; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalClassRearGPX = 0x40a0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalHoodGPX = 0x40a8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto AuxLightINT = 0x40b0; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto AuxLightPhys = 0x40b8; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto WidgetDigitalDisplayRacelogic = 0x40c0; // Size: 8, Type: struct UWidgetComponent*
			constexpr auto WingFin = 0x40c8; // Size: 8, Type: struct UWingComponent*
			constexpr auto BackFireL = 0x40d0; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto BackFireR = 0x40d8; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto DownForce RR = 0x40e0; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DownForce RL = 0x40e8; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DownForce FR = 0x40f0; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DownForce FL = 0x40f8; // Size: 8, Type: struct UDownForceComponent*
			constexpr auto DecalClassRearROWE = 0x4100; // Size: 8, Type: struct UDecalComponent*
			constexpr auto TestSpark = 0x4108; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ParticleSystem3 = 0x4110; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ParticleSystem2 = 0x4118; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto ParticleSystem1 = 0x4120; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto Driver_Enter_Exit = 0x4128; // Size: 8, Type: struct UArrowComponent*
	}
} 
