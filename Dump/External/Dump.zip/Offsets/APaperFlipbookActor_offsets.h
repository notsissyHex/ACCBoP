namespace offsets
{
	namespace APaperFlipbookActor
	{
			constexpr auto RenderComponent = 0x220; // Size: 8, Type: struct UPaperFlipbookComponent*
	}
} 
