namespace offsets
{
	namespace ATriggerCapsule
	{
	}
} 
