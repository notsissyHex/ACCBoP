namespace offsets
{
	namespace ATriggerSphere
	{
	}
} 
