namespace offsets
{
	namespace AGeneratedMeshAreaLight
	{
	}
} 
