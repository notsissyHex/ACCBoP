namespace offsets
{
	namespace AMagicLeapARPinInfoActor_C
	{
			constexpr auto UberGraphFrame = 0x238; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto Right = 0x240; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Forward = 0x248; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Up = 0x250; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto ValidRadiusVisualizer = 0x258; // Size: 8, Type: struct USphereComponent*
			constexpr auto AxisRoot = 0x260; // Size: 8, Type: struct USceneComponent*
			constexpr auto VisualizerRoot = 0x268; // Size: 8, Type: struct USceneComponent*
			constexpr auto TypeValue = 0x270; // Size: 8, Type: struct UTextRenderComponent*
			constexpr auto TransErrValue = 0x278; // Size: 8, Type: struct UTextRenderComponent*
			constexpr auto RotErrValue = 0x280; // Size: 8, Type: struct UTextRenderComponent*
			constexpr auto ConfidenceValue = 0x288; // Size: 8, Type: struct UTextRenderComponent*
			constexpr auto TransErrLabel = 0x290; // Size: 8, Type: struct UTextRenderComponent*
			constexpr auto RotErrLabel = 0x298; // Size: 8, Type: struct UTextRenderComponent*
			constexpr auto ConfidenceLabel = 0x2a0; // Size: 8, Type: struct UTextRenderComponent*
			constexpr auto PinIDValue = 0x2a8; // Size: 8, Type: struct UTextRenderComponent*
			constexpr auto InfoRoot = 0x2b0; // Size: 8, Type: struct USceneComponent*
			constexpr auto Root = 0x2b8; // Size: 8, Type: struct USceneComponent*
			constexpr auto RotationSmoothSpeed = 0x2c0; // Size: 4, Type: float
	}
} 
