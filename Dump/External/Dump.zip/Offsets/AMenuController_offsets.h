namespace offsets
{
	namespace AMenuController
	{
			constexpr auto CareerMainPage = 0x570; // Size: 8, Type: UUserWidget*
			constexpr auto ChampMainPage = 0x578; // Size: 8, Type: UUserWidget*
			constexpr auto BlackCurtainClass = 0x580; // Size: 8, Type: UUserWidget*
			constexpr auto MainPageClass = 0x588; // Size: 8, Type: UUserWidget*
			constexpr auto IntroPageClass = 0x590; // Size: 8, Type: UUserWidget*
			constexpr auto FirstLaunchClass = 0x598; // Size: 8, Type: UUserWidget*
			constexpr auto IsDirectInputListening = 0x5a0; // Size: 1, Type: bool
			constexpr auto GameMode = 0x5a8; // Size: 8, Type: struct AAcMenuGameMode*
			constexpr auto GameInstance = 0x5b0; // Size: 8, Type: struct UAcGameInstance*
	}
} 
