namespace offsets
{
	namespace ABP_MenuGameMode_C
	{
			constexpr auto UberGraphFrame = 0x620; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto DefaultSceneRoot = 0x628; // Size: 8, Type: struct USceneComponent*
	}
} 
