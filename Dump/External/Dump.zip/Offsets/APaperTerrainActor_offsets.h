namespace offsets
{
	namespace APaperTerrainActor
	{
			constexpr auto DummyRoot = 0x220; // Size: 8, Type: struct USceneComponent*
			constexpr auto SplineComponent = 0x228; // Size: 8, Type: struct UPaperTerrainSplineComponent*
			constexpr auto RenderComponent = 0x230; // Size: 8, Type: struct UPaperTerrainComponent*
	}
} 
