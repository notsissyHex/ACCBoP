namespace offsets
{
	namespace ANavigationGraph
	{
	}
} 
