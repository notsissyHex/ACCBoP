namespace offsets
{
	namespace AAcParticles
	{
			constexpr auto TestMesh = 0x220; // Size: 8, Type: struct UProceduralMeshComponent*
			constexpr auto TestMaterial = 0x228; // Size: 8, Type: struct UMaterial*
			constexpr auto BaseColorFactorNode = 0x230; // Size: 8, Type: struct UMaterialExpressionConstant3Vector*
			constexpr auto ParticlesArray = 0x248; // Size: 16, Type: struct TArray<struct UParticleSystemComponent*>
	}
} 
