namespace offsets
{
	namespace ASpotLight
	{
			constexpr auto SpotLightComponent = 0x230; // Size: 8, Type: struct USpotLightComponent*
	}
} 
