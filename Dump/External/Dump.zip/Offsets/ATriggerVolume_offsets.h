namespace offsets
{
	namespace ATriggerVolume
	{
	}
} 
