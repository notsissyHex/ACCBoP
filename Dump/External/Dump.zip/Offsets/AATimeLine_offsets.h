namespace offsets
{
	namespace AATimeLine
	{
			constexpr auto ID = 0x220; // Size: 4, Type: int32_t
			constexpr auto Left = 0x228; // Size: 8, Type: struct UBoxComponent*
			constexpr auto Right = 0x230; // Size: 8, Type: struct UBoxComponent*
	}
} 
