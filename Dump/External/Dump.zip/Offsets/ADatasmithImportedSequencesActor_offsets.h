namespace offsets
{
	namespace ADatasmithImportedSequencesActor
	{
			constexpr auto ImportedSequences = 0x220; // Size: 16, Type: struct TArray<struct ULevelSequence*>
	}
} 
