namespace offsets
{
	namespace AnewUI_C
	{
			constexpr auto OnKeyboardEvent = 0x228; // Size: 16, Type: struct FMulticastInlineDelegate
	}
} 
