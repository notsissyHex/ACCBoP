namespace offsets
{
	namespace ADetourCrowdAIController
	{
	}
} 
