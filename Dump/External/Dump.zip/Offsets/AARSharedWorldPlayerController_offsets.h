namespace offsets
{
	namespace AARSharedWorldPlayerController
	{
	}
} 
