namespace offsets
{
	namespace ABP_Pitstop_with_palette_C
	{
			constexpr auto UberGraphFrame = 0x5e0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto PanelRight = 0x5e8; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto PanelLeft = 0x5f0; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto PitCrew_PALETTE_RIGHT = 0x5f8; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Lollipop_Man_Right = 0x600; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto PitCrew_PALETTE_LEFT = 0x608; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Lollipop_Man_Left = 0x610; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto RefuellerMan = 0x618; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto TyreD = 0x620; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto TyreA = 0x628; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto TyreBC = 0x630; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto GEO_TyreDouble = 0x638; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto GEO_TyreSingle = 0x640; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Refueller_rigged_1 = 0x648; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto Refueller_static_1 = 0x650; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Airgun = 0x658; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto arrow = 0x660; // Size: 8, Type: struct UArrowComponent*
			constexpr auto ReceiverMan = 0x668; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto TyreMan = 0x670; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto AirgunMan = 0x678; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto PitcrewStart = 0x680; // Size: 8, Type: struct UArrowComponent*
			constexpr auto CarCenter = 0x688; // Size: 8, Type: struct UArrowComponent*
			constexpr auto Template_Pit_Stop = 0x690; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto IsDebug = 0x698; // Size: 1, Type: bool
			constexpr auto Offset = 0x69c; // Size: 12, Type: struct FVector
			constexpr auto deltaOffset = 0x6a8; // Size: 12, Type: struct FVector
	}
} 
