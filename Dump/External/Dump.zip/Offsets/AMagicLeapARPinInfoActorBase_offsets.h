namespace offsets
{
	namespace AMagicLeapARPinInfoActorBase
	{
			constexpr auto PinId = 0x220; // Size: 16, Type: struct FGuid
			constexpr auto bVisibilityOverride = 0x230; // Size: 1, Type: bool
	}
} 
