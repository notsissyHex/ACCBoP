namespace offsets
{
	namespace ASceneCapture
	{
			constexpr auto MeshComp = 0x220; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto SceneComponent = 0x228; // Size: 8, Type: struct USceneComponent*
	}
} 
