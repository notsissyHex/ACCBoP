namespace offsets
{
	namespace ARaceRatingDebugHUD
	{
	}
} 
