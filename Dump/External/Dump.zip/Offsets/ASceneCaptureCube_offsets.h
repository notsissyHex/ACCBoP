namespace offsets
{
	namespace ASceneCaptureCube
	{
			constexpr auto CaptureComponentCube = 0x230; // Size: 8, Type: struct USceneCaptureComponentCube*
	}
} 
