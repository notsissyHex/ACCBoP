namespace offsets
{
	namespace ABP_podium_cinematic_C
	{
			constexpr auto UberGraphFrame = 0x220; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto Spectator_B = 0x228; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto Spectator_A = 0x230; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto Spectator_C_Var = 0x238; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto SpotLight1 = 0x240; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto public_fake2 = 0x248; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto box3 = 0x250; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto box2 = 0x258; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto box1 = 0x260; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto SpotLight = 0x268; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto BP_temp_podium_4 = 0x270; // Size: 8, Type: struct UChildActorComponent*
			constexpr auto BP_temp_podium_2 = 0x278; // Size: 8, Type: struct UChildActorComponent*
			constexpr auto BP_temp_podium_3 = 0x280; // Size: 8, Type: struct UChildActorComponent*
			constexpr auto BP_PlayerStart1 = 0x288; // Size: 8, Type: struct UChildActorComponent*
			constexpr auto BP_PlayerStart2 = 0x290; // Size: 8, Type: struct UChildActorComponent*
			constexpr auto PS_Flash = 0x298; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto PS_Confetti1 = 0x2a0; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto PS_Confetti = 0x2a8; // Size: 8, Type: struct UParticleSystemComponent*
			constexpr auto RectLight1 = 0x2b0; // Size: 8, Type: struct URectLightComponent*
			constexpr auto Podium_floor = 0x2b8; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto VillageB = 0x2c0; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto RectLight = 0x2c8; // Size: 8, Type: struct URectLightComponent*
			constexpr auto StaticMesh9 = 0x2d0; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Flag_paddock = 0x2d8; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto StaticMesh6 = 0x2e0; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto satellite_van = 0x2e8; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto TENT_Mid = 0x2f0; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto SRO_Hospitality_GEO_AlfaTEST = 0x2f8; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto SRO_Hospitality_GEO_SRO_Hospitality_Flat = 0x300; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto BP_PlayerStart3 = 0x308; // Size: 8, Type: struct UChildActorComponent*
			constexpr auto SRO_Crossed_Arms = 0x310; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto SRO_Hands_in_Pockets = 0x318; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Photographer_3 = 0x320; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Photographer_2 = 0x328; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Marshall_Crossed_Arms = 0x330; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Barrier_podium_scene = 0x338; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Circuit_Crew_Idle = 0x340; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Circuit_Crew_HAnds_on_Waist = 0x348; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Circuit_Crew_Crossed_Arms = 0x350; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Podium_camera = 0x358; // Size: 8, Type: struct UCameraComponent*
			constexpr auto DefaultSceneRoot = 0x360; // Size: 8, Type: struct USceneComponent*
	}
} 
