namespace offsets
{
	namespace AMatineeActorCameraAnim
	{
			constexpr auto CameraAnim = 0x2c8; // Size: 8, Type: struct UCameraAnim*
	}
} 
