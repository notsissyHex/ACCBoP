namespace offsets
{
	namespace ARadialForceActor
	{
			constexpr auto ForceComponent = 0x220; // Size: 8, Type: struct URadialForceComponent*
	}
} 
