namespace offsets
{
	namespace AVolumetricLightmapDensityVolume
	{
			constexpr auto AllowedMipLevelRange = 0x258; // Size: 8, Type: struct FInt32Interval
	}
} 
