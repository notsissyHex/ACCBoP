namespace offsets
{
	namespace AMaterialInstanceActor
	{
			constexpr auto TargetActors = 0x220; // Size: 16, Type: struct TArray<struct AActor*>
	}
} 
