namespace offsets
{
	namespace AWheeledVehicle
	{
			constexpr auto Mesh = 0x280; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto VehicleMovement = 0x288; // Size: 8, Type: struct UWheeledVehicleMovementComponent*
	}
} 
