namespace offsets
{
	namespace AAbstractNavData
	{
	}
} 
