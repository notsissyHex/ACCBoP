namespace offsets
{
	namespace ATS_FireworksLauncher_C
	{
			constexpr auto UberGraphFrame = 0x230; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto text = 0x238; // Size: 8, Type: struct UTextRenderComponent*
			constexpr auto arrow = 0x240; // Size: 8, Type: struct UArrowComponent*
			constexpr auto ROOT_Sphere = 0x248; // Size: 8, Type: struct USphereComponent*
			constexpr auto AutoLaunch = 0x250; // Size: 1, Type: bool
			constexpr auto NumberOfLaunches = 0x254; // Size: 4, Type: int32_t
			constexpr auto SecondsBetweenLaunches = 0x258; // Size: 4, Type: float
			constexpr auto RandomAngle = 0x25c; // Size: 4, Type: float
			constexpr auto BurstParticleSystems = 0x260; // Size: 16, Type: struct TArray<struct UParticleSystem*>
			constexpr auto MaxRotationSpeed = 0x270; // Size: 4, Type: float
			constexpr auto MinRotationSpeed = 0x274; // Size: 4, Type: float
			constexpr auto MaxLaunchVelocity = 0x278; // Size: 4, Type: float
			constexpr auto MinLaunchVelocity = 0x27c; // Size: 4, Type: float
			constexpr auto ShellMaxLife = 0x280; // Size: 4, Type: float
			constexpr auto ShellminLife = 0x284; // Size: 4, Type: float
			constexpr auto MaxBurstTime = 0x288; // Size: 4, Type: float
			constexpr auto MinBurstTime = 0x28c; // Size: 4, Type: float
			constexpr auto ShellParticleSystem = 0x290; // Size: 8, Type: struct UParticleSystem*
			constexpr auto NumberOfBursts = 0x298; // Size: 4, Type: int32_t
			constexpr auto SecondaryBurstDelay = 0x29c; // Size: 4, Type: float
			constexpr auto FlareColor = 0x2a0; // Size: 16, Type: struct FLinearColor
			constexpr auto ShellTailColor = 0x2b0; // Size: 16, Type: struct FLinearColor
			constexpr auto UseShapedBurst = 0x2c0; // Size: 1, Type: bool
			constexpr auto BurstSparkleMultiplier = 0x2c4; // Size: 4, Type: float
			constexpr auto ShellSparkleMultiplier = 0x2c8; // Size: 4, Type: float
			constexpr auto BurstStarMultiplier = 0x2cc; // Size: 4, Type: float
			constexpr auto UseShellSmoke = 0x2d0; // Size: 1, Type: bool
			constexpr auto UseBurstSmoke = 0x2d1; // Size: 1, Type: bool
			constexpr auto ShapedBurstActorMesh = 0x2d8; // Size: 8, Type: struct USkeletalMesh*
			constexpr auto RandomRotation = 0x2e0; // Size: 1, Type: bool
	}
} 
