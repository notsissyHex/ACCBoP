namespace offsets
{
	namespace ATriggerBox
	{
	}
} 
