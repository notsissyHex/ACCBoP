namespace offsets
{
	namespace ADriverAvatar
	{
			constexpr auto RaceMesh = 0x4b8; // Size: 8, Type: struct USkeletalMesh*
			constexpr auto ShowroomMesh = 0x4c0; // Size: 8, Type: struct USkeletalMesh*
	}
} 
