namespace offsets
{
	namespace UABP_Marshall_Flag_C
	{
			constexpr auto UberGraphFrame = 0x2c0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x2c8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_TransitionResult_5 = 0x2f8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_4 = 0x320; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_3 = 0x348; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_2 = 0x370; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult = 0x398; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_StateResult_5 = 0x3c0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_BlendSpacePlayer_4 = 0x3f0; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_LayeredBoneBlend_4 = 0x4d8; // Size: 192, Type: struct FAnimNode_LayeredBoneBlend
			constexpr auto AnimGraphNode_SequencePlayer_4 = 0x598; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_4 = 0x618; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_BlendSpacePlayer_3 = 0x648; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_LayeredBoneBlend_3 = 0x730; // Size: 192, Type: struct FAnimNode_LayeredBoneBlend
			constexpr auto AnimGraphNode_SequencePlayer_3 = 0x7f0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_3 = 0x870; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_BlendSpacePlayer_2 = 0x8a0; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_LayeredBoneBlend_2 = 0x988; // Size: 192, Type: struct FAnimNode_LayeredBoneBlend
			constexpr auto AnimGraphNode_SequencePlayer_2 = 0xa48; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_2 = 0xac8; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_BlendSpacePlayer = 0xaf8; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_LayeredBoneBlend = 0xbe0; // Size: 192, Type: struct FAnimNode_LayeredBoneBlend
			constexpr auto AnimGraphNode_SequencePlayer = 0xca0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult = 0xd20; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0xd50; // Size: 176, Type: struct FAnimNode_StateMachine
			constexpr auto use flag = 0xe00; // Size: 1, Type: bool
			constexpr auto look left right = 0xe04; // Size: 4, Type: float
			constexpr auto BPOwner = 0xe08; // Size: 8, Type: struct ABP_Marshall_Flag_C*
			constexpr auto start idle = 0xe10; // Size: 1, Type: bool
	}
} 
