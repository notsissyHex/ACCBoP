namespace offsets
{
	namespace AARSkyLight
	{
			constexpr auto CaptureProbe = 0x230; // Size: 8, Type: struct UAREnvironmentCaptureProbe*
	}
} 
