namespace offsets
{
	namespace UABP_Pit_Crew_AIRGUN_C
	{
			constexpr auto UberGraphFrame = 0x2d0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x2d8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_TransitionResult_11 = 0x308; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_10 = 0x330; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_9 = 0x358; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_8 = 0x380; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_7 = 0x3a8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_6 = 0x3d0; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_5 = 0x3f8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_4 = 0x420; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_3 = 0x448; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_2 = 0x470; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult = 0x498; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_SequencePlayer_2 = 0x4c0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_5 = 0x540; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequenceEvaluator_3 = 0x570; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_StateResult_4 = 0x5c0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequenceEvaluator_2 = 0x5f0; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_StateResult_3 = 0x640; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequenceEvaluator = 0x670; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_StateResult_2 = 0x6c0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_BlendSpacePlayer = 0x6f0; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_LayeredBoneBlend = 0x7d8; // Size: 192, Type: struct FAnimNode_LayeredBoneBlend
			constexpr auto AnimGraphNode_SequencePlayer = 0x898; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult = 0x918; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0x948; // Size: 176, Type: struct FAnimNode_StateMachine
			constexpr auto GoToPositionAnim = 0x9f8; // Size: 8, Type: struct UAnimSequence*
			constexpr auto StartChangeAnim = 0xa00; // Size: 8, Type: struct UAnimSequence*
			constexpr auto EndGestureAnim = 0xa08; // Size: 8, Type: struct UAnimSequence*
			constexpr auto AfterGoToPosition = 0xa10; // Size: 1, Type: bool
			constexpr auto AfterStartChange = 0xa11; // Size: 1, Type: bool
			constexpr auto AfterEndGesture = 0xa12; // Size: 1, Type: bool
			constexpr auto TEMP = 0xa14; // Size: 4, Type: float
			constexpr auto Change_anim = 0xa18; // Size: 4, Type: float
			constexpr auto move_to_position = 0xa1c; // Size: 4, Type: float
			constexpr auto End_gesture = 0xa20; // Size: 4, Type: float
			constexpr auto move_offset = 0xa24; // Size: 4, Type: float
	}
} 
