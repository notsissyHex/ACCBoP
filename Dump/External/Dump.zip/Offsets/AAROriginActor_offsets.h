namespace offsets
{
	namespace AAROriginActor
	{
	}
} 
