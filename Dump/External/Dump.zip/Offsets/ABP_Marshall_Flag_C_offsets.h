namespace offsets
{
	namespace ABP_Marshall_Flag_C
	{
			constexpr auto UberGraphFrame = 0x298; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto StaticMesh_placement = 0x2a0; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Marshall_Flagger_A = 0x2a8; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto FlagMaterial = 0x2b0; // Size: 8, Type: struct UMaterialInstanceDynamic*
			constexpr auto Meshes = 0x2b8; // Size: 16, Type: struct TArray<struct USkeletalMesh*>
			constexpr auto Anim = 0x2c8; // Size: 8, Type: struct UABP_Marshall_Flag_C*
			constexpr auto CurrentFlag = 0x2d0; // Size: 1, Type: enum class EMarshalFlagType
	}
} 
