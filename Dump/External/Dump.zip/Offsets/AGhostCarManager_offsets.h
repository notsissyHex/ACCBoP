namespace offsets
{
	namespace AGhostCarManager
	{
			constexpr auto MinDistance = 0x220; // Size: 4, Type: float
			constexpr auto MaxDistance = 0x224; // Size: 4, Type: float
			constexpr auto MaxOpacity = 0x228; // Size: 4, Type: float
			constexpr auto StartingFadeExtension = 0x22c; // Size: 4, Type: float
			constexpr auto BaseColor = 0x230; // Size: 16, Type: struct FLinearColor
			constexpr auto RedVariation = 0x240; // Size: 4, Type: float
			constexpr auto GreenVariation = 0x244; // Size: 4, Type: float
			constexpr auto ghostCarAvatar = 0x248; // Size: 8, Type: struct ACarAvatar*
	}
} 
