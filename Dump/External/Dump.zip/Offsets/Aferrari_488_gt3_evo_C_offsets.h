namespace offsets
{
	namespace Aferrari_488_gt3_evo_C
	{
			constexpr auto UberGraphFrame = 0x4188; // Size: 8, Type: struct FPointerToUberGraphFrame
	}
} 
