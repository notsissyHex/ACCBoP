namespace offsets
{
	namespace ACableActor
	{
			constexpr auto CableComponent = 0x220; // Size: 8, Type: struct UCableComponent*
	}
} 
