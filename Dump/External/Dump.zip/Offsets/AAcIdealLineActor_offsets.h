namespace offsets
{
	namespace AAcIdealLineActor
	{
			constexpr auto IdealLineSpacing = 0x220; // Size: 4, Type: int32_t
			constexpr auto IdealLineWidth = 0x224; // Size: 4, Type: int32_t
			constexpr auto GroundOffset = 0x228; // Size: 4, Type: float
			constexpr auto SecondsToNextPoint = 0x22c; // Size: 4, Type: int32_t
			constexpr auto SpeedLimitOver = 0x230; // Size: 4, Type: int32_t
			constexpr auto SpeedLimitUnder = 0x234; // Size: 4, Type: int32_t
			constexpr auto ColorOver = 0x238; // Size: 16, Type: struct FLinearColor
			constexpr auto ColorUnder = 0x248; // Size: 16, Type: struct FLinearColor
			constexpr auto ColorMiddle = 0x258; // Size: 16, Type: struct FLinearColor
			constexpr auto Material = 0x268; // Size: 8, Type: struct UMaterialInterface*
			constexpr auto LineMesh = 0x270; // Size: 8, Type: struct UProceduralMeshComponent*
	}
} 
