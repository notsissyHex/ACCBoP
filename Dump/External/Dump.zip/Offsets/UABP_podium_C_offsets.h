namespace offsets
{
	namespace UABP_podium_C
	{
			constexpr auto UberGraphFrame = 0x2c0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x2c8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_TransitionResult_10 = 0x2f8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_9 = 0x320; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_8 = 0x348; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_7 = 0x370; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_6 = 0x398; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_5 = 0x3c0; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_4 = 0x3e8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_3 = 0x410; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_2 = 0x438; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult = 0x460; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_SequencePlayer_11 = 0x488; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_11 = 0x508; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_10 = 0x538; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_10 = 0x5b8; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_9 = 0x5e8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_9 = 0x668; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_8 = 0x698; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_8 = 0x718; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_7 = 0x748; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_7 = 0x7c8; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_6 = 0x7f8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_6 = 0x878; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_5 = 0x8a8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_5 = 0x928; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_4 = 0x958; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_4 = 0x9d8; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_3 = 0xa08; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_3 = 0xa88; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_2 = 0xab8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_2 = 0xb38; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer = 0xb68; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult = 0xbe8; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0xc18; // Size: 176, Type: struct FAnimNode_StateMachine
			constexpr auto pose_hips = 0xcc8; // Size: 1, Type: bool
			constexpr auto victory_jump_a = 0xcc9; // Size: 1, Type: bool
			constexpr auto pose_standing = 0xcca; // Size: 1, Type: bool
			constexpr auto victory_gesture_a = 0xccb; // Size: 1, Type: bool
			constexpr auto plaude = 0xccc; // Size: 1, Type: bool
			constexpr auto victory_gesture_b = 0xccd; // Size: 1, Type: bool
			constexpr auto 1st = 0xcce; // Size: 1, Type: bool
			constexpr auto 2nd = 0xccf; // Size: 1, Type: bool
			constexpr auto 3rd = 0xcd0; // Size: 1, Type: bool
	}
} 
