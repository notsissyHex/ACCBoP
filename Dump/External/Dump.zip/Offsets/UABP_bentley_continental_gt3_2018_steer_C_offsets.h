namespace offsets
{
	namespace UABP_bentley_continental_gt3_2018_steer_C
	{
			constexpr auto UberGraphFrame = 0x2f0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x2f8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_TransitionResult_5 = 0x328; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_4 = 0x350; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_3 = 0x378; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_2 = 0x3a0; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult = 0x3c8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_StateResult_4 = 0x3f0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_ModifyBone_12 = 0x420; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_11 = 0x528; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_10 = 0x630; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ComponentToLocalSpace_3 = 0x738; // Size: 32, Type: struct FAnimNode_ConvertComponentToLocalSpace
			constexpr auto AnimGraphNode_LocalToComponentSpace_3 = 0x758; // Size: 32, Type: struct FAnimNode_ConvertLocalToComponentSpace
			constexpr auto AnimGraphNode_ModifyBone_9 = 0x778; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_SequencePlayer_5 = 0x880; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_4 = 0x900; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_2 = 0x980; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_StateResult_3 = 0xa48; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_ModifyBone_8 = 0xa78; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_7 = 0xb80; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_6 = 0xc88; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ComponentToLocalSpace_2 = 0xd90; // Size: 32, Type: struct FAnimNode_ConvertComponentToLocalSpace
			constexpr auto AnimGraphNode_LocalToComponentSpace_2 = 0xdb0; // Size: 32, Type: struct FAnimNode_ConvertLocalToComponentSpace
			constexpr auto AnimGraphNode_ModifyBone_5 = 0xdd0; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_SequencePlayer_3 = 0xed8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_2 = 0xf58; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive = 0xfd8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_StateResult_2 = 0x10a0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_ModifyBone_4 = 0x10d0; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_3 = 0x11d8; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_2 = 0x12e0; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ComponentToLocalSpace = 0x13e8; // Size: 32, Type: struct FAnimNode_ConvertComponentToLocalSpace
			constexpr auto AnimGraphNode_LocalToComponentSpace = 0x1408; // Size: 32, Type: struct FAnimNode_ConvertLocalToComponentSpace
			constexpr auto AnimGraphNode_ModifyBone = 0x1428; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_SequencePlayer = 0x1530; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult = 0x15b0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0x15e0; // Size: 176, Type: struct FAnimNode_StateMachine
	}
} 
