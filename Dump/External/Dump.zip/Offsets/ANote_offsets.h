namespace offsets
{
	namespace ANote
	{
	}
} 
