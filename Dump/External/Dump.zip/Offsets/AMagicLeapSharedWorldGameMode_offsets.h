namespace offsets
{
	namespace AMagicLeapSharedWorldGameMode
	{
			constexpr auto SharedWorldData = 0x308; // Size: 16, Type: struct FMagicLeapSharedWorldSharedData
			constexpr auto OnNewLocalDataFromClients = 0x318; // Size: 16, Type: struct FMulticastInlineDelegate
			constexpr auto PinSelectionConfidenceThreshold = 0x328; // Size: 4, Type: float
			constexpr auto ChosenOne = 0x3d0; // Size: 8, Type: struct AMagicLeapSharedWorldPlayerController*
	}
} 
