namespace offsets
{
	namespace ASkyLight
	{
			constexpr auto LightComponent = 0x220; // Size: 8, Type: struct USkyLightComponent*
			constexpr auto bEnabled = 0x228; // Size: 1, Type: char
	}
} 
