namespace offsets
{
	namespace APhysicsThruster
	{
			constexpr auto ThrusterComponent = 0x220; // Size: 8, Type: struct UPhysicsThrusterComponent*
	}
} 
