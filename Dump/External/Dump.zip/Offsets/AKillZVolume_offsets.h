namespace offsets
{
	namespace AKillZVolume
	{
	}
} 
