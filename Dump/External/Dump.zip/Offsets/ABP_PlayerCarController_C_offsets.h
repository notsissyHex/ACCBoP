namespace offsets
{
	namespace ABP_PlayerCarController_C
	{
			constexpr auto UberGraphFrame = 0x698; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto PhysicsHUD = 0x6a0; // Size: 8, Type: struct UObject*
			constexpr auto CinemaHUD = 0x6a8; // Size: 8, Type: struct UWBP_CinemaHud_C*
			constexpr auto ReplayHUD_1 = 0x6b0; // Size: 8, Type: struct UWBP_Replay_C*
			constexpr auto Ingamepause = 0x6b8; // Size: 8, Type: struct UObject*
			constexpr auto TelemetryHUDIndex = 0x6c0; // Size: 4, Type: int32_t
	}
} 
