namespace offsets
{
	namespace ALevelBounds
	{
			constexpr auto BoxComponent = 0x220; // Size: 8, Type: struct UBoxComponent*
			constexpr auto bAutoUpdateBounds = 0x228; // Size: 1, Type: bool
	}
} 
