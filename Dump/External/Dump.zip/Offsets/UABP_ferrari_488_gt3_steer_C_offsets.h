namespace offsets
{
	namespace UABP_ferrari_488_gt3_steer_C
	{
			constexpr auto UberGraphFrame = 0x2f0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x2f8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_TransitionResult_5 = 0x328; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_4 = 0x350; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_3 = 0x378; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_2 = 0x3a0; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult = 0x3c8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_StateResult_4 = 0x3f0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_ModifyBone_3 = 0x420; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ComponentToLocalSpace_3 = 0x528; // Size: 32, Type: struct FAnimNode_ConvertComponentToLocalSpace
			constexpr auto AnimGraphNode_LocalToComponentSpace_3 = 0x548; // Size: 32, Type: struct FAnimNode_ConvertLocalToComponentSpace
			constexpr auto AnimGraphNode_SequencePlayer_5 = 0x568; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_4 = 0x5e8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_2 = 0x668; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_StateResult_3 = 0x730; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_ModifyBone_2 = 0x760; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ComponentToLocalSpace_2 = 0x868; // Size: 32, Type: struct FAnimNode_ConvertComponentToLocalSpace
			constexpr auto AnimGraphNode_LocalToComponentSpace_2 = 0x888; // Size: 32, Type: struct FAnimNode_ConvertLocalToComponentSpace
			constexpr auto AnimGraphNode_SequencePlayer_3 = 0x8a8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_2 = 0x928; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive = 0x9a8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_StateResult_2 = 0xa70; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_ModifyBone = 0xaa0; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ComponentToLocalSpace = 0xba8; // Size: 32, Type: struct FAnimNode_ConvertComponentToLocalSpace
			constexpr auto AnimGraphNode_LocalToComponentSpace = 0xbc8; // Size: 32, Type: struct FAnimNode_ConvertLocalToComponentSpace
			constexpr auto AnimGraphNode_SequencePlayer = 0xbe8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult = 0xc68; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0xc98; // Size: 176, Type: struct FAnimNode_StateMachine
	}
} 
