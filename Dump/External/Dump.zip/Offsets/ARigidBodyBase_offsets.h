namespace offsets
{
	namespace ARigidBodyBase
	{
	}
} 
