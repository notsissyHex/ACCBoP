namespace offsets
{
	namespace AAdvancedScalabilityConfig
	{
			constexpr auto SaveFlag = 0x220; // Size: 4, Type: float
			constexpr auto LightFunctionQuality = 0x224; // Size: 4, Type: float
			constexpr auto ShadowQuality = 0x228; // Size: 4, Type: float
			constexpr auto MaxCascades = 0x22c; // Size: 4, Type: float
			constexpr auto ShadowMaxResolution = 0x230; // Size: 4, Type: float
			constexpr auto RadiusThreshold = 0x234; // Size: 4, Type: float
			constexpr auto DistanceScale = 0x238; // Size: 4, Type: float
			constexpr auto TransitionScale = 0x23c; // Size: 4, Type: float
			constexpr auto MotionBlurQuality = 0x240; // Size: 4, Type: float
			constexpr auto BlurGBuffer = 0x244; // Size: 4, Type: float
			constexpr auto AmbientOcclusionLevels = 0x248; // Size: 4, Type: float
			constexpr auto AmbientOcclusionRadiusScale = 0x24c; // Size: 4, Type: float
			constexpr auto DepthOfFieldQuality = 0x250; // Size: 4, Type: float
			constexpr auto RenderTargetPoolMin = 0x254; // Size: 4, Type: float
			constexpr auto LensFlareQuality = 0x258; // Size: 4, Type: float
			constexpr auto SceneColorFringeQuality = 0x25c; // Size: 4, Type: float
			constexpr auto EyeAdaptationQuality = 0x260; // Size: 4, Type: float
			constexpr auto BloomQuality = 0x264; // Size: 4, Type: float
			constexpr auto FastBlurThreshold = 0x268; // Size: 4, Type: float
			constexpr auto UpscaleQuality = 0x26c; // Size: 4, Type: float
			constexpr auto GrainQuantization = 0x270; // Size: 4, Type: float
			constexpr auto TranslucensyVolumeDim = 0x274; // Size: 4, Type: float
			constexpr auto RefractionQuality = 0x278; // Size: 4, Type: float
			constexpr auto SSR = 0x27c; // Size: 4, Type: float
			constexpr auto SceneColorFormat = 0x280; // Size: 4, Type: float
			constexpr auto DetailMode = 0x284; // Size: 4, Type: float
			constexpr auto TranslucencyVolumeBlur = 0x288; // Size: 4, Type: float
			constexpr auto MaterialQualityLevel = 0x28c; // Size: 4, Type: float
	}
} 
