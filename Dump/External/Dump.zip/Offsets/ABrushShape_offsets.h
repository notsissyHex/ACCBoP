namespace offsets
{
	namespace ABrushShape
	{
	}
} 
