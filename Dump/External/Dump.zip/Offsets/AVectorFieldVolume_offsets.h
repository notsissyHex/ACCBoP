namespace offsets
{
	namespace AVectorFieldVolume
	{
			constexpr auto VectorFieldComponent = 0x220; // Size: 8, Type: struct UVectorFieldComponent*
	}
} 
