namespace offsets
{
	namespace UABP_bmw_m2_cs_racing_net_C
	{
			constexpr auto UberGraphFrame = 0x2e0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x2e8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_TransitionResult_7 = 0x318; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_6 = 0x340; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_5 = 0x368; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_4 = 0x390; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_3 = 0x3b8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_2 = 0x3e0; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult = 0x408; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_StateResult_6 = 0x430; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateResult_5 = 0x460; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_3 = 0x490; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_4 = 0x510; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateResult_3 = 0x540; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_2 = 0x570; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_2 = 0x5f0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer = 0x620; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_BlendSpacePlayer_2 = 0x6a0; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_2 = 0x788; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_BlendSpacePlayer = 0x850; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_ApplyAdditive = 0x938; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_StateResult = 0xa00; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0xa30; // Size: 176, Type: struct FAnimNode_StateMachine
	}
} 
