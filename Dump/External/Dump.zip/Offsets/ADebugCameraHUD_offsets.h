namespace offsets
{
	namespace ADebugCameraHUD
	{
	}
} 
