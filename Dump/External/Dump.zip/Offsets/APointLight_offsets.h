namespace offsets
{
	namespace APointLight
	{
			constexpr auto PointLightComponent = 0x230; // Size: 8, Type: struct UPointLightComponent*
	}
} 
