namespace offsets
{
	namespace AGeometryCollectionActor
	{
			constexpr auto GeometryCollectionComponent = 0x220; // Size: 8, Type: struct UGeometryCollectionComponent*
			constexpr auto GeometryCollectionDebugDrawComponent = 0x228; // Size: 8, Type: struct UGeometryCollectionDebugDrawComponent*
	}
} 
