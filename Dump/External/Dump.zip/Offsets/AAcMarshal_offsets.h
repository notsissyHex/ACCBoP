namespace offsets
{
	namespace AAcMarshal
	{
			constexpr auto winColor = 0x220; // Size: 1, Type: enum class EMarshalFlagType
			constexpr auto startAnimationRandom = 0x224; // Size: 4, Type: float
			constexpr auto StartPosition = 0x228; // Size: 4, Type: float
			constexpr auto MiddlePosition = 0x22c; // Size: 4, Type: float
			constexpr auto EndPosition = 0x230; // Size: 4, Type: float
			constexpr auto bCanDrawLines = 0x234; // Size: 1, Type: bool
			constexpr auto ForcedMiddlePosition = 0x238; // Size: 4, Type: float
			constexpr auto StartBox = 0x240; // Size: 8, Type: struct UBoxComponent*
			constexpr auto MiddleBox = 0x248; // Size: 8, Type: struct UBoxComponent*
			constexpr auto EndBox = 0x250; // Size: 8, Type: struct UBoxComponent*
			constexpr auto animTest = 0x258; // Size: 8, Type: struct UAnimInstance*
	}
} 
