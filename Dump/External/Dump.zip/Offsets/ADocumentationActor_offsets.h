namespace offsets
{
	namespace ADocumentationActor
	{
	}
} 
