namespace offsets
{
	namespace ABP_Driver_configurator_C
	{
			constexpr auto UberGraphFrame = 0x220; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto Driver_Head = 0x228; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Driver_Helmet = 0x230; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto Driver = 0x238; // Size: 8, Type: struct USkeletalMeshComponent*
	}
} 
