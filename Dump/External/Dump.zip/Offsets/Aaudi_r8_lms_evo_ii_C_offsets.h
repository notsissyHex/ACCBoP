namespace offsets
{
	namespace Aaudi_r8_lms_evo_ii_C
	{
			constexpr auto UberGraphFrame = 0x41c8; // Size: 8, Type: struct FPointerToUberGraphFrame
	}
} 
