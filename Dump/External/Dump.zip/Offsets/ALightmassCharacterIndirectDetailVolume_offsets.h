namespace offsets
{
	namespace ALightmassCharacterIndirectDetailVolume
	{
	}
} 
