namespace offsets
{
	namespace AExponentialHeightFog
	{
			constexpr auto Component = 0x220; // Size: 8, Type: struct UExponentialHeightFogComponent*
			constexpr auto bEnabled = 0x228; // Size: 1, Type: char
	}
} 
