namespace offsets
{
	namespace UABP_ginetta_g55_gt4_driver_C
	{
			constexpr auto UberGraphFrame = 0x3c0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x3c8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_BlendSpacePlayer_4 = 0x3f8; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_17 = 0x4e0; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_16 = 0x5a8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_13 = 0x670; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_BlendSpacePlayer_3 = 0x6f0; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_15 = 0x7d8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_12 = 0x8a0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_14 = 0x920; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_13 = 0x9e8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_11 = 0xab0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_12 = 0xb30; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_10 = 0xbf8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_11 = 0xc78; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_9 = 0xd40; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_10 = 0xdc0; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_9 = 0xe88; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_8 = 0xf50; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_7 = 0x1018; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_6 = 0x10e0; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_8 = 0x11a8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_7 = 0x1228; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_6 = 0x12a8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_5 = 0x1328; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_4 = 0x13a8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_BlendSpacePlayer_2 = 0x1428; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_BlendSpacePlayer = 0x1510; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_5 = 0x15f8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_4 = 0x16c0; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_3 = 0x1788; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_2 = 0x1850; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_3 = 0x1918; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_2 = 0x1998; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequenceEvaluator = 0x1a18; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_SequencePlayer = 0x1a68; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive = 0x1ae8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_StateResult = 0x1bb0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0x1be0; // Size: 176, Type: struct FAnimNode_StateMachine
	}
} 
