namespace offsets
{
	namespace ASceneCapture2D
	{
			constexpr auto CaptureComponent2D = 0x230; // Size: 8, Type: struct USceneCaptureComponent2D*
	}
} 
