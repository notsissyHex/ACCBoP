namespace offsets
{
	namespace AInfo
	{
	}
} 
