namespace offsets
{
	namespace ADatasmithSceneActor
	{
			constexpr auto Scene = 0x220; // Size: 8, Type: struct UDatasmithScene*
			constexpr auto RelatedActors = 0x228; // Size: 80, Type: struct TMap<struct FName, struct TSoftObjectPtr<AActor>>
	}
} 
