namespace offsets
{
	namespace ABP_RaceGameState_C
	{
			constexpr auto DefaultSceneRoot = 0x390; // Size: 8, Type: struct USceneComponent*
	}
} 
