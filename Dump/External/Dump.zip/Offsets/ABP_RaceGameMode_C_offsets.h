namespace offsets
{
	namespace ABP_RaceGameMode_C
	{
			constexpr auto UberGraphFrame = 0x10e0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto DefaultSceneRoot = 0x10e8; // Size: 8, Type: struct USceneComponent*
			constexpr auto Sky = 0x10f0; // Size: 8, Type: struct AUltra_Dynamic_Sky_BP_C*
			constexpr auto TempCar = 0x10f8; // Size: 8, Type: struct APawn*
			constexpr auto DirectionLight = 0x1100; // Size: 8, Type: struct ADirectionalLight*
			constexpr auto DebugIndex = 0x1108; // Size: 4, Type: int32_t
			constexpr auto Instance = 0x1110; // Size: 8, Type: struct UBP_GameInstance_C*
	}
} 
