namespace offsets
{
	namespace UABP_Pit_Crew_Palette_RIGHT_C
	{
			constexpr auto UberGraphFrame = 0x2d0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x2d8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_TransitionResult_8 = 0x308; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_7 = 0x330; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_6 = 0x358; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_5 = 0x380; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_4 = 0x3a8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_3 = 0x3d0; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_2 = 0x3f8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult = 0x420; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_SequenceEvaluator_2 = 0x448; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_StateResult_4 = 0x498; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_2 = 0x4c8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_3 = 0x548; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequenceEvaluator = 0x578; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_StateResult_2 = 0x5c8; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer = 0x5f8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult = 0x678; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0x6a8; // Size: 176, Type: struct FAnimNode_StateMachine
			constexpr auto AfterExpose = 0x758; // Size: 1, Type: bool
			constexpr auto ExposeAnim = 0x760; // Size: 8, Type: struct UAnimSequence*
			constexpr auto IdleAnim = 0x768; // Size: 8, Type: struct UAnimSequence*
			constexpr auto LookBack = 0x770; // Size: 8, Type: struct UAnimSequence*
			constexpr auto expose_start_time = 0x778; // Size: 4, Type: float
			constexpr auto end_time = 0x77c; // Size: 4, Type: float
	}
} 
