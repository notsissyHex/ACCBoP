namespace offsets
{
	namespace AARActor
	{
	}
} 
