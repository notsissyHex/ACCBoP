namespace offsets
{
	namespace UABP_Pit_Crew_RECEIVER_C
	{
			constexpr auto UberGraphFrame = 0x2d0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x2d8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_TransitionResult_5 = 0x308; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_4 = 0x330; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_3 = 0x358; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_2 = 0x380; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult = 0x3a8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_SequencePlayer_2 = 0x3d0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_3 = 0x450; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequenceEvaluator = 0x480; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_StateResult_2 = 0x4d0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_BlendSpacePlayer = 0x500; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_LayeredBoneBlend = 0x5e8; // Size: 192, Type: struct FAnimNode_LayeredBoneBlend
			constexpr auto AnimGraphNode_SequencePlayer = 0x6a8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult = 0x728; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0x758; // Size: 176, Type: struct FAnimNode_StateMachine
			constexpr auto receiveAnim = 0x808; // Size: 8, Type: struct UAnimSequence*
			constexpr auto take_tyre_time = 0x810; // Size: 4, Type: float
			constexpr auto AfterTakeTyre = 0x814; // Size: 1, Type: bool
			constexpr auto Offset = 0x818; // Size: 4, Type: float
	}
} 
