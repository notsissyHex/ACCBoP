namespace offsets
{
	namespace UABP_alpine_a110_gt4_steer_C
	{
			constexpr auto UberGraphFrame = 0x2f0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x2f8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_TransitionResult_5 = 0x328; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_4 = 0x350; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_3 = 0x378; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_2 = 0x3a0; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult = 0x3c8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_StateResult_4 = 0x3f0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_ModifyBone_9 = 0x420; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_8 = 0x528; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ComponentToLocalSpace_3 = 0x630; // Size: 32, Type: struct FAnimNode_ConvertComponentToLocalSpace
			constexpr auto AnimGraphNode_LocalToComponentSpace_3 = 0x650; // Size: 32, Type: struct FAnimNode_ConvertLocalToComponentSpace
			constexpr auto AnimGraphNode_ModifyBone_7 = 0x670; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_SequencePlayer_5 = 0x778; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_4 = 0x7f8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_2 = 0x878; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_StateResult_3 = 0x940; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_ModifyBone_6 = 0x970; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_5 = 0xa78; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ComponentToLocalSpace_2 = 0xb80; // Size: 32, Type: struct FAnimNode_ConvertComponentToLocalSpace
			constexpr auto AnimGraphNode_LocalToComponentSpace_2 = 0xba0; // Size: 32, Type: struct FAnimNode_ConvertLocalToComponentSpace
			constexpr auto AnimGraphNode_ModifyBone_4 = 0xbc0; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_SequencePlayer_3 = 0xcc8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_2 = 0xd48; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive = 0xdc8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_StateResult_2 = 0xe90; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_ModifyBone_3 = 0xec0; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_2 = 0xfc8; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ComponentToLocalSpace = 0x10d0; // Size: 32, Type: struct FAnimNode_ConvertComponentToLocalSpace
			constexpr auto AnimGraphNode_LocalToComponentSpace = 0x10f0; // Size: 32, Type: struct FAnimNode_ConvertLocalToComponentSpace
			constexpr auto AnimGraphNode_ModifyBone = 0x1110; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_SequencePlayer = 0x1218; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult = 0x1298; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0x12c8; // Size: 176, Type: struct FAnimNode_StateMachine
	}
} 
