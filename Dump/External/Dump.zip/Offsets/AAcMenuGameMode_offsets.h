namespace offsets
{
	namespace AAcMenuGameMode
	{
			constexpr auto CompetitionList = 0x2c8; // Size: 32, Type: struct FCompetitionList
			constexpr auto CustomCompetitionList = 0x2e8; // Size: 32, Type: struct FCompetitionList
			constexpr auto cars = 0x308; // Size: 80, Type: struct TMap<struct FName, struct FCarInfo>
			constexpr auto Drivers = 0x358; // Size: 80, Type: struct TMap<struct FName, struct FDriverInfo>
			constexpr auto CarSeason = 0x3a8; // Size: 80, Type: struct TMap<struct FName, enum class ESeasonType>
			constexpr auto carGroups = 0x3f8; // Size: 16, Type: struct TArray<enum class ECarGroup>
			constexpr auto gameModeDefaults = 0x408; // Size: 80, Type: struct TMap<enum class ESeasonType, struct FGuiSeasonRaceEventData>
			constexpr auto ScreenSaverCarModel = 0x458; // Size: 1, Type: enum class ECarModelType
			constexpr auto ScreenSaverCarName = 0x45c; // Size: 8, Type: struct FName
			constexpr auto OnSeasonChanged = 0x468; // Size: 16, Type: struct FMulticastInlineDelegate
			constexpr auto currentShowroomCar = 0x478; // Size: 8, Type: struct ACarAvatar*
			constexpr auto currentCockpitCamera = 0x480; // Size: 8, Type: struct UCameraComponent*
			constexpr auto currentShowroomCamera = 0x488; // Size: 8, Type: struct ACameraActor*
			constexpr auto lastSetCamera = 0x490; // Size: 8, Type: struct ACameraActor*
			constexpr auto currentShowroomDrivers = 0x498; // Size: 80, Type: struct TMap<struct FString, struct ADriverAvatar*>
			constexpr auto allowShowroomInteraction = 0x4e8; // Size: 1, Type: bool
			constexpr auto isInCockpitCam = 0x4e9; // Size: 1, Type: bool
			constexpr auto GameInstance = 0x4f0; // Size: 8, Type: struct UAcGameInstance*
			constexpr auto InputDeviceManager = 0x4f8; // Size: 8, Type: struct UAcInputDeviceManager*
			constexpr auto RaceGameModePath = 0x500; // Size: 16, Type: struct FString
			constexpr auto ViewOptions = 0x510; // Size: 8, Type: struct UViewOptionsLibrary*
			constexpr auto GuiCars = 0x518; // Size: 80, Type: struct TMap<enum class ECarModelType, struct FGuiCar>
			constexpr auto RaceEventGenerator = 0x578; // Size: 8, Type: struct UAcRaceEventGenerator*
	}
} 
