namespace offsets
{
	namespace ANavMeshBoundsVolume
	{
			constexpr auto SupportedAgents = 0x258; // Size: 4, Type: struct FNavAgentSelector
	}
} 
