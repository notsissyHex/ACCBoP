namespace offsets
{
	namespace AVolume
	{
	}
} 
