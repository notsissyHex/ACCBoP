namespace offsets
{
	namespace ABox_Monza_C
	{
			constexpr auto UberGraphFrame = 0x220; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto SpotLight = 0x228; // Size: 8, Type: struct USpotLightComponent*
			constexpr auto PointLight3 = 0x230; // Size: 8, Type: struct UPointLightComponent*
			constexpr auto PointLight2 = 0x238; // Size: 8, Type: struct UPointLightComponent*
			constexpr auto PointLight1 = 0x240; // Size: 8, Type: struct UPointLightComponent*
			constexpr auto PointLight = 0x248; // Size: 8, Type: struct UPointLightComponent*
			constexpr auto box_proto1_Object864 = 0x250; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto box_proto1_details_roof = 0x258; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto box_proto1_base = 0x260; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto box_proto1_anodyzed001 = 0x268; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto DefaultSceneRoot = 0x270; // Size: 8, Type: struct USceneComponent*
	}
} 
