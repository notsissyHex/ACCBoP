namespace offsets
{
	namespace ACullDistanceVolume
	{
			constexpr auto CullDistances = 0x258; // Size: 16, Type: struct TArray<struct FCullDistanceSizePair>
			constexpr auto bEnabled = 0x268; // Size: 1, Type: char
	}
} 
