namespace offsets
{
	namespace AWindDirectionalSource
	{
			constexpr auto Component = 0x220; // Size: 8, Type: struct UWindDirectionalSourceComponent*
	}
} 
