namespace offsets
{
	namespace ANavModifierVolume
	{
			constexpr auto AreaClass = 0x260; // Size: 8, Type: UNavArea*
			constexpr auto bMaskFillCollisionUnderneathForNavmesh = 0x268; // Size: 1, Type: bool
	}
} 
