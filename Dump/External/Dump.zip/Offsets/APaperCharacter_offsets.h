namespace offsets
{
	namespace APaperCharacter
	{
			constexpr auto Sprite = 0x4b8; // Size: 8, Type: struct UPaperFlipbookComponent*
	}
} 
