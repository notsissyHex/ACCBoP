namespace offsets
{
	namespace ARain2_C
	{
	}
} 
