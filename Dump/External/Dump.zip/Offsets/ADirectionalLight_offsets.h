namespace offsets
{
	namespace ADirectionalLight
	{
	}
} 
