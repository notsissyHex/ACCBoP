namespace offsets
{
	namespace UABP_maserati_mc_gt4_net_C
	{
			constexpr auto UberGraphFrame = 0x2f0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x2f8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_TransitionResult_7 = 0x328; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_6 = 0x350; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_5 = 0x378; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_4 = 0x3a0; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_3 = 0x3c8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_2 = 0x3f0; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult = 0x418; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_StateResult_6 = 0x440; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateResult_5 = 0x470; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_3 = 0x4a0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_4 = 0x520; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateResult_3 = 0x550; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_2 = 0x580; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_2 = 0x600; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer = 0x630; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_BlendSpacePlayer_2 = 0x6b0; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_2 = 0x798; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_BlendSpacePlayer = 0x860; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_ApplyAdditive = 0x948; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_StateResult = 0xa10; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0xa40; // Size: 176, Type: struct FAnimNode_StateMachine
	}
} 
