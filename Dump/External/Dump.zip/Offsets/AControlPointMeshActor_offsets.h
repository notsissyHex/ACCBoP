namespace offsets
{
	namespace AControlPointMeshActor
	{
			constexpr auto ControlPointMeshComponent = 0x220; // Size: 8, Type: struct UControlPointMeshComponent*
	}
} 
