namespace offsets
{
	namespace Aaudi_r8_lms_evo_C
	{
			constexpr auto UberGraphFrame = 0x4148; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto ClassFrontAttempto20_REF = 0x4150; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassBonnetIItalia_REF = 0x4158; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalBonnetItalia_REF = 0x4160; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFrontMonta_REF_1 = 0x4168; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRear_Club19_REF = 0x4170; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFrontClub19_REF = 0x4178; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassBonnet_WRT19_REF = 0x4180; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFrontPhoenix_REF = 0x4188; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassFrontAttempto19_REF = 0x4190; // Size: 8, Type: struct UDecalComponent*
			constexpr auto RearNumberTag_Attempto19_REF = 0x4198; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRearAttempto19_REF = 0x41a0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalRoofStloc_REF = 0x41a8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalBonnetStloc_REF = 0x41b0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalBonnetPhoenix_REF = 0x41b8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto RearNumberTag_REF_WRT = 0x41c0; // Size: 8, Type: struct UDecalComponent*
	}
} 
