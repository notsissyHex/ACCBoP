namespace offsets
{
	namespace UABP_Pit_Crew_TYREMAN_C
	{
			constexpr auto UberGraphFrame = 0x2d0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x2d8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_TransitionResult_8 = 0x308; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_7 = 0x330; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_6 = 0x358; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_5 = 0x380; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_4 = 0x3a8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_3 = 0x3d0; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_2 = 0x3f8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult = 0x420; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_SequenceEvaluator_2 = 0x448; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_StateResult_4 = 0x498; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer = 0x4c8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_3 = 0x548; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequenceEvaluator = 0x578; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_StateResult_2 = 0x5c8; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_BlendSpacePlayer = 0x5f8; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_StateResult = 0x6e0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0x710; // Size: 176, Type: struct FAnimNode_StateMachine
			constexpr auto GoToPositionAnim = 0x7c0; // Size: 8, Type: struct UAnimSequence*
			constexpr auto StartChangeAnim = 0x7c8; // Size: 8, Type: struct UAnimSequence*
			constexpr auto AfterStartChange = 0x7d0; // Size: 1, Type: bool
			constexpr auto AfterGoToPosition = 0x7d1; // Size: 1, Type: bool
			constexpr auto move_to_position = 0x7d4; // Size: 4, Type: float
			constexpr auto Change_anim = 0x7d8; // Size: 4, Type: float
	}
} 
