namespace offsets
{
	namespace ANetController
	{
	}
} 
