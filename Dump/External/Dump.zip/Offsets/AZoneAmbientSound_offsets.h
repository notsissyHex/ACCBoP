namespace offsets
{
	namespace AZoneAmbientSound
	{
			constexpr auto AmbientSound = 0x220; // Size: 8, Type: struct UFMODAudioComponent*
			constexpr auto OuterSphere = 0x228; // Size: 8, Type: struct USphereComponent*
			constexpr auto InnerSphere = 0x230; // Size: 8, Type: struct USphereComponent*
			constexpr auto OnlyFocusedCar = 0x238; // Size: 1, Type: bool
			constexpr auto SpeedUpdate = 0x239; // Size: 1, Type: bool
			constexpr auto UseFading = 0x23a; // Size: 1, Type: bool
	}
} 
