namespace offsets
{
	namespace ADefaultPhysicsVolume
	{
	}
} 
