namespace offsets
{
	namespace UABP_Driver_configurator_C
	{
			constexpr auto UberGraphFrame = 0x2c0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x2c8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_TransitionResult_19 = 0x2f8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_18 = 0x320; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_17 = 0x348; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_16 = 0x370; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_15 = 0x398; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_14 = 0x3c0; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_13 = 0x3e8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_12 = 0x410; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_11 = 0x438; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_10 = 0x460; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_9 = 0x488; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_8 = 0x4b0; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_7 = 0x4d8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_6 = 0x500; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_5 = 0x528; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_4 = 0x550; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_3 = 0x578; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult_2 = 0x5a0; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_TransitionResult = 0x5c8; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_SequencePlayer_14 = 0x5f0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_14 = 0x670; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_13 = 0x6a0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_13 = 0x720; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_12 = 0x750; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_12 = 0x7d0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_11 = 0x800; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_11 = 0x880; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_10 = 0x8b0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_10 = 0x930; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_9 = 0x960; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_9 = 0x9e0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_8 = 0xa10; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_8 = 0xa90; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_7 = 0xac0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_7 = 0xb40; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_6 = 0xb70; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_6 = 0xbf0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_5 = 0xc20; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_5 = 0xca0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_4 = 0xcd0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_4 = 0xd50; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_3 = 0xd80; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_3 = 0xe00; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer_2 = 0xe30; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult_2 = 0xeb0; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequencePlayer = 0xee0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_StateResult = 0xf60; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0xf90; // Size: 176, Type: struct FAnimNode_StateMachine
			constexpr auto Sit down = 0x1040; // Size: 1, Type: bool
			constexpr auto Adjust Gloves = 0x1041; // Size: 1, Type: bool
			constexpr auto Arms on hips = 0x1042; // Size: 1, Type: bool
			constexpr auto Open Glass = 0x1043; // Size: 1, Type: bool
			constexpr auto Close Glass = 0x1044; // Size: 1, Type: bool
			constexpr auto Driver = 0x1048; // Size: 8, Type: struct ABP_Driver_configurator_C*
			constexpr auto Cross_arms-on = 0x1050; // Size: 1, Type: bool
	}
} 
