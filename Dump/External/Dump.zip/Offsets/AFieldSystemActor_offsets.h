namespace offsets
{
	namespace AFieldSystemActor
	{
			constexpr auto FieldSystemComponent = 0x220; // Size: 8, Type: struct UFieldSystemComponent*
	}
} 
