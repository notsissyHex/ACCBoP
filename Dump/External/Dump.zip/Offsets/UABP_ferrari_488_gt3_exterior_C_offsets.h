namespace offsets
{
	namespace UABP_ferrari_488_gt3_exterior_C
	{
			constexpr auto UberGraphFrame = 0x3d0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x3d8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_TransitionResult = 0x408; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_LocalRefPose = 0x430; // Size: 24, Type: struct FAnimNode_RefPose
			constexpr auto AnimGraphNode_StateResult_2 = 0x448; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequenceEvaluator_3 = 0x478; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_SequenceEvaluator_2 = 0x4c8; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_ModifyBone_20 = 0x518; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_19 = 0x620; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_18 = 0x728; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_17 = 0x830; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_16 = 0x938; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_15 = 0xa40; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_14 = 0xb48; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_13 = 0xc50; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_12 = 0xd58; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_11 = 0xe60; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_10 = 0xf68; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_9 = 0x1070; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_8 = 0x1178; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_7 = 0x1280; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_6 = 0x1388; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_5 = 0x1490; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_MeshRefPose = 0x1598; // Size: 16, Type: struct FAnimNode_MeshSpaceRefPose
			constexpr auto AnimGraphNode_ComponentToLocalSpace = 0x15a8; // Size: 32, Type: struct FAnimNode_ConvertComponentToLocalSpace
			constexpr auto AnimGraphNode_ModifyBone_4 = 0x15c8; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_3 = 0x16d0; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_2 = 0x17d8; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone = 0x18e0; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_SequenceEvaluator = 0x19e8; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_ApplyAdditive_3 = 0x1a38; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_2 = 0x1b00; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive = 0x1bc8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_StateResult = 0x1c90; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0x1cc0; // Size: 176, Type: struct FAnimNode_StateMachine
	}
} 
