namespace offsets
{
	namespace ASphereReflectionCapture
	{
			constexpr auto DrawCaptureRadius = 0x228; // Size: 8, Type: struct UDrawSphereComponent*
	}
} 
