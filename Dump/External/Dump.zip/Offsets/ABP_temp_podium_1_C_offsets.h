namespace offsets
{
	namespace ABP_temp_podium_1_C
	{
			constexpr auto UberGraphFrame = 0x220; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto Driver_Helmet = 0x228; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto Driver_Head = 0x230; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto Driver = 0x238; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto DefaultSceneRoot = 0x240; // Size: 8, Type: struct USceneComponent*
			constexpr auto Position = 0x248; // Size: 4, Type: int32_t
			constexpr auto Anim = 0x24c; // Size: 1, Type: enum class EPodiumAnim
	}
} 
