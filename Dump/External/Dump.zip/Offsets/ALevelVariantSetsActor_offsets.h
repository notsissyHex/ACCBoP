namespace offsets
{
	namespace ALevelVariantSetsActor
	{
			constexpr auto LevelVariantSets = 0x220; // Size: 24, Type: struct FSoftObjectPath
	}
} 
