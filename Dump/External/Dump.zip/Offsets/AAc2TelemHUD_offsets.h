namespace offsets
{
	namespace AAc2TelemHUD
	{
	}
} 
