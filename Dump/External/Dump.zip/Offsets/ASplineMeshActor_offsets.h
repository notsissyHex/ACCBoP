namespace offsets
{
	namespace ASplineMeshActor
	{
			constexpr auto SplineMeshComponent = 0x220; // Size: 8, Type: struct USplineMeshComponent*
	}
} 
