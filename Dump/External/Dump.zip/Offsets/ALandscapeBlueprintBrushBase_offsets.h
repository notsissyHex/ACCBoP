namespace offsets
{
	namespace ALandscapeBlueprintBrushBase
	{
	}
} 
