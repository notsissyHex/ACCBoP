namespace offsets
{
	namespace Alamborghini_huracan_st_evo2_C
	{
			constexpr auto UberGraphFrame = 0x40e0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto ClassRear_REF1 = 0x40e8; // Size: 8, Type: struct UDecalComponent*
	}
} 
