namespace offsets
{
	namespace ARainBase
	{
			constexpr auto Template = 0x220; // Size: 8, Type: struct UParticleSystem*
			constexpr auto EmitterSize = 0x228; // Size: 12, Type: struct FVector
			constexpr auto VerticalOffset = 0x234; // Size: 4, Type: float
			constexpr auto VelocityMaxSpeed = 0x238; // Size: 4, Type: float
			constexpr auto ParticleChildren = 0x240; // Size: 16, Type: struct TArray<struct UParticleSystemComponent*>
	}
} 
