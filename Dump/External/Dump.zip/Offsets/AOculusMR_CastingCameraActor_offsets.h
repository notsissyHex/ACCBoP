namespace offsets
{
	namespace AOculusMR_CastingCameraActor
	{
			constexpr auto VRNotificationComponent = 0x238; // Size: 8, Type: struct UVRNotificationsComponent*
			constexpr auto CameraColorTexture = 0x240; // Size: 8, Type: struct UTexture2D*
			constexpr auto CameraDepthTexture = 0x248; // Size: 8, Type: struct UTexture2D*
			constexpr auto PlaneMeshComponent = 0x250; // Size: 8, Type: struct UOculusMR_PlaneMeshComponent*
			constexpr auto ChromaKeyMaterial = 0x258; // Size: 8, Type: struct UMaterial*
			constexpr auto OpaqueColoredMaterial = 0x260; // Size: 8, Type: struct UMaterial*
			constexpr auto ChromaKeyMaterialInstance = 0x268; // Size: 8, Type: struct UMaterialInstanceDynamic*
			constexpr auto CameraFrameMaterialInstance = 0x270; // Size: 8, Type: struct UMaterialInstanceDynamic*
			constexpr auto BackdropMaterialInstance = 0x278; // Size: 8, Type: struct UMaterialInstanceDynamic*
			constexpr auto DefaultTexture_White = 0x280; // Size: 8, Type: struct UTexture2D*
			constexpr auto BackgroundRenderTargets = 0x2d8; // Size: 16, Type: struct TArray<struct UTextureRenderTarget2D*>
			constexpr auto ForegroundCaptureActor = 0x2e8; // Size: 8, Type: struct ASceneCapture2D*
			constexpr auto ForegroundRenderTargets = 0x2f0; // Size: 16, Type: struct TArray<struct UTextureRenderTarget2D*>
			constexpr auto PoseTimes = 0x300; // Size: 16, Type: struct TArray<double>
			constexpr auto MRSettings = 0x310; // Size: 8, Type: struct UOculusMR_Settings*
			constexpr auto MRState = 0x318; // Size: 8, Type: struct UOculusMR_State*
	}
} 
