namespace offsets
{
	namespace AIntervalGizmoActor
	{
			constexpr auto UpIntervalComponent = 0x220; // Size: 8, Type: struct UGizmoLineHandleComponent*
			constexpr auto DownIntervalComponent = 0x228; // Size: 8, Type: struct UGizmoLineHandleComponent*
			constexpr auto ForwardIntervalComponent = 0x230; // Size: 8, Type: struct UGizmoLineHandleComponent*
	}
} 
