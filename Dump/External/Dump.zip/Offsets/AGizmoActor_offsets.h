namespace offsets
{
	namespace AGizmoActor
	{
	}
} 
