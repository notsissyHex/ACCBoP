namespace offsets
{
	namespace ATestBeaconHost
	{
	}
} 
