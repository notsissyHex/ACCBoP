namespace offsets
{
	namespace AARSharedWorldGameMode
	{
			constexpr auto BufferSizePerChunk = 0x308; // Size: 4, Type: int32_t
	}
} 
