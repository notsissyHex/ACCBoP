namespace offsets
{
	namespace ARealtimePositionsDebugHud
	{
	}
} 
