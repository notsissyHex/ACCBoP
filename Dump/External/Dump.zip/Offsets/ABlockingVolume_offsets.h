namespace offsets
{
	namespace ABlockingVolume
	{
	}
} 
