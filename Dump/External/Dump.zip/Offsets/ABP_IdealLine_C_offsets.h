namespace offsets
{
	namespace ABP_IdealLine_C
	{
			constexpr auto UberGraphFrame = 0x2d8; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto InstancedStaticMesh = 0x2e0; // Size: 8, Type: struct UInstancedStaticMeshComponent*
	}
} 
