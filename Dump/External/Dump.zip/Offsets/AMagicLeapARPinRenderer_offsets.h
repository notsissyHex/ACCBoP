namespace offsets
{
	namespace AMagicLeapARPinRenderer
	{
			constexpr auto bInfoActorsVisibilityOverride = 0x220; // Size: 1, Type: bool
			constexpr auto AllInfoActors = 0x228; // Size: 80, Type: struct TMap<struct FGuid, struct AMagicLeapARPinInfoActorBase*>
			constexpr auto ClassToSpawn = 0x280; // Size: 8, Type: AMagicLeapARPinInfoActorBase*
	}
} 
