namespace offsets
{
	namespace ARectLight
	{
			constexpr auto RectLightComponent = 0x230; // Size: 8, Type: struct URectLightComponent*
	}
} 
