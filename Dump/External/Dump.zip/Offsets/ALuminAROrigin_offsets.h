namespace offsets
{
	namespace ALuminAROrigin
	{
			constexpr auto MRMeshComponent = 0x220; // Size: 8, Type: struct UMRMeshComponent*
			constexpr auto PlaneSurfaceMaterial = 0x228; // Size: 8, Type: struct UMaterialInterface*
			constexpr auto WireframeMaterial = 0x230; // Size: 8, Type: struct UMaterialInterface*
	}
} 
