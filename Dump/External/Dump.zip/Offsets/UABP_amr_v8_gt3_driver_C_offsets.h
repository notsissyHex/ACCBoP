namespace offsets
{
	namespace UABP_amr_v8_gt3_driver_C
	{
			constexpr auto UberGraphFrame = 0x3c0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x3c8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_BlendSpacePlayer_4 = 0x3f8; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_23 = 0x4e0; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_19 = 0x5a8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_22 = 0x628; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_21 = 0x6f0; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_18 = 0x7b8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_BlendSpacePlayer_3 = 0x838; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_20 = 0x920; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_17 = 0x9e8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_19 = 0xa68; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_18 = 0xb30; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_16 = 0xbf8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_17 = 0xc78; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_15 = 0xd40; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_16 = 0xdc0; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_15 = 0xe88; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_14 = 0xf50; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_13 = 0xfd0; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_14 = 0x1050; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_13 = 0x1118; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_12 = 0x11e0; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_11 = 0x12a8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_10 = 0x1370; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_9 = 0x1438; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_8 = 0x1500; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_7 = 0x15c8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_6 = 0x1690; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_12 = 0x1758; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_11 = 0x17d8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_10 = 0x1858; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_9 = 0x18d8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_8 = 0x1958; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_7 = 0x19d8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_6 = 0x1a58; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_5 = 0x1ad8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_4 = 0x1b58; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_BlendSpacePlayer_2 = 0x1bd8; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_BlendSpacePlayer = 0x1cc0; // Size: 232, Type: struct FAnimNode_BlendSpacePlayer
			constexpr auto AnimGraphNode_ApplyAdditive_5 = 0x1da8; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_4 = 0x1e70; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_3 = 0x1f38; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_2 = 0x2000; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_SequencePlayer_3 = 0x20c8; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequencePlayer_2 = 0x2148; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_SequenceEvaluator = 0x21c8; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_SequencePlayer = 0x2218; // Size: 128, Type: struct FAnimNode_SequencePlayer
			constexpr auto AnimGraphNode_ApplyAdditive = 0x2298; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_StateResult = 0x2360; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0x2390; // Size: 176, Type: struct FAnimNode_StateMachine
	}
} 
