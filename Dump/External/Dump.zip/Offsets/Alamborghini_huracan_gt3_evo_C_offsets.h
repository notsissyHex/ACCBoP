namespace offsets
{
	namespace Alamborghini_huracan_gt3_evo_C
	{
			constexpr auto UberGraphFrame = 0x4108; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto PlateHood_REF_FFF = 0x4110; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRear_REF_Barwell19 = 0x4118; // Size: 8, Type: struct UDecalComponent*
			constexpr auto Tag_REF_Barwell19 = 0x4120; // Size: 8, Type: struct UDecalComponent*
			constexpr auto Tag_REF_Target19 = 0x4128; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRear_REF_Target19 = 0x4130; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassHood_REF_Boutsen = 0x4138; // Size: 8, Type: struct UDecalComponent*
	}
} 
