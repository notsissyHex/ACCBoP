namespace offsets
{
	namespace AAIInfoHUD
	{
	}
} 
