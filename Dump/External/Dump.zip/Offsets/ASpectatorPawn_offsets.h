namespace offsets
{
	namespace ASpectatorPawn
	{
	}
} 
