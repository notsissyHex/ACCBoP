namespace offsets
{
	namespace AReplayActor
	{
	}
} 
