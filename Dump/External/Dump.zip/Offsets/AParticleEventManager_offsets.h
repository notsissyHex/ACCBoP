namespace offsets
{
	namespace AParticleEventManager
	{
	}
} 
