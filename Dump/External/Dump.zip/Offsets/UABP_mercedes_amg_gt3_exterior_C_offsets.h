namespace offsets
{
	namespace UABP_mercedes_amg_gt3_exterior_C
	{
			constexpr auto UberGraphFrame = 0x3d0; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto AnimGraphNode_Root = 0x3d8; // Size: 48, Type: struct FAnimNode_Root
			constexpr auto AnimGraphNode_TransitionResult = 0x408; // Size: 40, Type: struct FAnimNode_TransitionResult
			constexpr auto AnimGraphNode_StateResult_2 = 0x430; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_SequenceEvaluator_3 = 0x460; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_SequenceEvaluator_2 = 0x4b0; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_ModifyBone_20 = 0x500; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_19 = 0x608; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_18 = 0x710; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_17 = 0x818; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_16 = 0x920; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_15 = 0xa28; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_14 = 0xb30; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_13 = 0xc38; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_SequenceEvaluator = 0xd40; // Size: 80, Type: struct FAnimNode_SequenceEvaluator
			constexpr auto AnimGraphNode_ApplyAdditive_3 = 0xd90; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive_2 = 0xe58; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ApplyAdditive = 0xf20; // Size: 200, Type: struct FAnimNode_ApplyAdditive
			constexpr auto AnimGraphNode_ModifyBone_12 = 0xfe8; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_11 = 0x10f0; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_10 = 0x11f8; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_9 = 0x1300; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_8 = 0x1408; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_7 = 0x1510; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_6 = 0x1618; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_5 = 0x1720; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_MeshRefPose = 0x1828; // Size: 16, Type: struct FAnimNode_MeshSpaceRefPose
			constexpr auto AnimGraphNode_ComponentToLocalSpace = 0x1838; // Size: 32, Type: struct FAnimNode_ConvertComponentToLocalSpace
			constexpr auto AnimGraphNode_ModifyBone_4 = 0x1858; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_3 = 0x1960; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone_2 = 0x1a68; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_ModifyBone = 0x1b70; // Size: 264, Type: struct FAnimNode_ModifyBone
			constexpr auto AnimGraphNode_StateResult = 0x1c78; // Size: 48, Type: struct FAnimNode_StateResult
			constexpr auto AnimGraphNode_StateMachine = 0x1ca8; // Size: 176, Type: struct FAnimNode_StateMachine
	}
} 
