namespace offsets
{
	namespace AHeliCamera
	{
			constexpr auto heliAudio = 0x7a0; // Size: 8, Type: struct UFMODAudioComponent*
	}
} 
