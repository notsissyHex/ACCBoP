namespace offsets
{
	namespace AAcCarLocationManager
	{
			constexpr auto Version = 0x220; // Size: 1, Type: char
			constexpr auto PitEntryLaneSideStart = 0x228; // Size: 8, Type: struct ATriggerBox*
			constexpr auto PitEntryLaneSide = 0x230; // Size: 8, Type: struct ATriggerVolume*
			constexpr auto PitLaneEntry = 0x238; // Size: 8, Type: struct ATriggerBox*
			constexpr auto PitLaneExit = 0x240; // Size: 8, Type: struct ATriggerBox*
			constexpr auto PitExitLaneSide = 0x248; // Size: 8, Type: struct ATriggerVolume*
			constexpr auto PitExitLaneEnd = 0x250; // Size: 8, Type: struct ATriggerBox*
			constexpr auto PitEntryLaneStartName = 0x258; // Size: 8, Type: struct FName
			constexpr auto PitEntryLaneStart_v2 = 0x260; // Size: 8, Type: struct ATriggerBase*
			constexpr auto PitEntryLaneSideName = 0x268; // Size: 8, Type: struct FName
			constexpr auto PitEntryLaneSide_v2 = 0x270; // Size: 16, Type: struct TArray<struct ATriggerBase*>
			constexpr auto PitLaneEntryName = 0x280; // Size: 8, Type: struct FName
			constexpr auto PitLaneEntry_v2 = 0x288; // Size: 8, Type: struct ATriggerBase*
			constexpr auto PitLaneExitName = 0x290; // Size: 8, Type: struct FName
			constexpr auto PitLaneExit_v2 = 0x298; // Size: 8, Type: struct ATriggerBase*
			constexpr auto PitExitLaneSideName = 0x2a0; // Size: 8, Type: struct FName
			constexpr auto PitExitLaneSide_v2 = 0x2a8; // Size: 16, Type: struct TArray<struct ATriggerBase*>
			constexpr auto PitExitLaneEndName = 0x2b8; // Size: 8, Type: struct FName
			constexpr auto PitExitLaneEnd_v2 = 0x2c0; // Size: 8, Type: struct ATriggerBase*
			constexpr auto SafetyCarLine1Name = 0x2c8; // Size: 8, Type: struct FName
			constexpr auto SafetyCarLine2Name = 0x2d0; // Size: 8, Type: struct FName
			constexpr auto PitBridge1StartName = 0x2d8; // Size: 8, Type: struct FName
			constexpr auto PitBridge1Start = 0x2e0; // Size: 8, Type: struct ATriggerBase*
			constexpr auto PitBridge1EndName = 0x2e8; // Size: 8, Type: struct FName
			constexpr auto PitBridge1End = 0x2f0; // Size: 8, Type: struct ATriggerBase*
	}
} 
