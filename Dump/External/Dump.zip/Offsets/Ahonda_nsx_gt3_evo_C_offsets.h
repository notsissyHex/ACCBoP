namespace offsets
{
	namespace Ahonda_nsx_gt3_evo_C
	{
			constexpr auto UberGraphFrame = 0x40d8; // Size: 8, Type: struct FPointerToUberGraphFrame
			constexpr auto DecalHood_REF1 = 0x40e0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto NumberDoor_L_IGT = 0x40e8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto NumberDoor_R_IGT = 0x40f0; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRear_REF_Motul = 0x40f8; // Size: 8, Type: struct UDecalComponent*
			constexpr auto RearNumberTag_REF_Motul = 0x4100; // Size: 8, Type: struct UDecalComponent*
			constexpr auto RearNumberTag_REF_RJN = 0x4108; // Size: 8, Type: struct UDecalComponent*
			constexpr auto DecalRoof_REF_RJN = 0x4110; // Size: 8, Type: struct UDecalComponent*
			constexpr auto ClassRear_REF_RJN = 0x4118; // Size: 8, Type: struct UDecalComponent*
	}
} 
