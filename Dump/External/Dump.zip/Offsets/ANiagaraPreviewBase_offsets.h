namespace offsets
{
	namespace ANiagaraPreviewBase
	{
	}
} 
