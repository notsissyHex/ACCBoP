namespace offsets
{
	namespace AAcPitstopProcedure
	{
			constexpr auto switchTyre = 0x228; // Size: 1, Type: enum class EPitstopSwitchTyre
			constexpr auto CurrentAnimationTime = 0x22c; // Size: 4, Type: float
			constexpr auto previousOffsetAirgun = 0x230; // Size: 12, Type: struct FVector
			constexpr auto previousOffsetA = 0x23c; // Size: 12, Type: struct FVector
			constexpr auto previousOffsetBC = 0x248; // Size: 12, Type: struct FVector
			constexpr auto previousOffsetD = 0x254; // Size: 12, Type: struct FVector
			constexpr auto BlendTime = 0x260; // Size: 4, Type: float
			constexpr auto elapsedBlendTime = 0x264; // Size: 4, Type: float
			constexpr auto SceneComponent = 0x268; // Size: 8, Type: struct USceneComponent*
			constexpr auto tyreManComponent = 0x270; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto airgunManComponent = 0x288; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto refuellerManComponent = 0x2a0; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto receiverManComponent = 0x2b8; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto tyreA_Component = 0x2d0; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto tyreBC_Component = 0x2e8; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto tyreD_Component = 0x300; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto refuellerSkeletal = 0x318; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto lollipopManLeft = 0x320; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto lollipopManRight = 0x328; // Size: 8, Type: struct USkeletalMeshComponent*
			constexpr auto refuellerStatic = 0x330; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto tyreSingleStatic = 0x338; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto tyreDoubleStatic = 0x340; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto airGunStatic = 0x348; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto lollipopLeft = 0x350; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto lollipopRight = 0x358; // Size: 8, Type: struct UStaticMeshComponent*
			constexpr auto pitStart = 0x360; // Size: 8, Type: struct USceneComponent*
			constexpr auto pitTyreComponents = 0x368; // Size: 16, Type: struct TArray<struct UStaticMeshComponent*>
			constexpr auto carTyreComponents = 0x378; // Size: 16, Type: struct TArray<struct UStaticMeshComponent*>
			constexpr auto pitRimComponents = 0x388; // Size: 16, Type: struct TArray<struct UStaticMeshComponent*>
			constexpr auto carRimComponents = 0x398; // Size: 16, Type: struct TArray<struct UStaticMeshComponent*>
			constexpr auto rimMeshes = 0x3a8; // Size: 16, Type: struct TArray<struct UStaticMesh*>
			constexpr auto carCenterComponent = 0x3b8; // Size: 8, Type: struct UArrowComponent*
			constexpr auto pitWheelSockets = 0x3c0; // Size: 16, Type: struct TArray<struct USkeletalMeshSocket*>
			constexpr auto carWheelSockets = 0x3d0; // Size: 16, Type: struct TArray<struct USkeletalMeshSocket*>
			constexpr auto wheelComponents = 0x3e0; // Size: 16, Type: struct TArray<struct USkeletalMeshComponent*>
			constexpr auto switch_mesh_at_time = 0x3f0; // Size: 80, Type: struct TMap<enum class EPitstopSwitchTyre, float>
			constexpr auto airgun_position_at_time = 0x440; // Size: 80, Type: struct TMap<enum class EPitstopSwitchTyre, struct FVector>
			constexpr auto crew_phase_start = 0x490; // Size: 80, Type: struct TMap<enum class EPitstopCrewPhases, float>
			constexpr auto crew_phase_end = 0x4e0; // Size: 80, Type: struct TMap<enum class EPitstopCrewPhases, float>
			constexpr auto audio_events = 0x530; // Size: 16, Type: struct TArray<struct FTyreAudio>
			constexpr auto phase = 0x540; // Size: 1, Type: enum class EPitstopCrewPhases
			constexpr auto AnimationOffset = 0x544; // Size: 12, Type: struct FVector
	}
} 
