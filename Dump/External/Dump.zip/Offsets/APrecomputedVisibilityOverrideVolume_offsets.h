namespace offsets
{
	namespace APrecomputedVisibilityOverrideVolume
	{
			constexpr auto OverrideVisibleActors = 0x258; // Size: 16, Type: struct TArray<struct AActor*>
			constexpr auto OverrideInvisibleActors = 0x268; // Size: 16, Type: struct TArray<struct AActor*>
			constexpr auto OverrideInvisibleLevels = 0x278; // Size: 16, Type: struct TArray<struct FName>
	}
} 
